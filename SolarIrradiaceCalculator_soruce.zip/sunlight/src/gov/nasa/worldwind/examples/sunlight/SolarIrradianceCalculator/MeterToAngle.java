package gov.nasa.worldwind.examples.sunlight.SolarIrradianceCalculator;

/**
 * Copyright (C) 2001 United States Government
 * as represented by the Administrator of the
 * National Aeronautics and Space Administration.
 * All Rights Reserved.
 * @author  Marco Piragnolo
 * Cirgeo, University of Padua, francesco.pirotti@unipd.it, marco.piragnolo@unipd.it
 * @version 0.1  2014-29-05 11:46
 */

import gov.nasa.worldwind.geom.Angle;
import gov.nasa.worldwind.geom.LatLon;
import gov.nasa.worldwind.geom.Position;
import gov.nasa.worldwind.globes.Globe;
import gov.nasa.worldwind.render.DrawContext;

public class MeterToAngle 
{	/**Calculate the latitude-longitude angle from a distance (meter)*/		
	public Angle latMetersAngle(double meter, double lat, double lon, Globe globe, DrawContext dc)
	{	/**Calculate the latitude angle from a distance in meter*/
		Position position=new Position(Position.fromDegrees(lat, lon),0);
		Angle a=Angle.fromDegrees(1);
		Position addpos = new Position(position.getLatitude().add(a), position.getLongitude(), 0);			
		double dist= (double)Math.round((LatLon.ellipsoidalDistance(position, addpos, 6378100, 6356800)));
		Angle yres= a.multiply(meter).divide(dist);
		return yres;
	}
		
	public Angle lonMetersAngle(double meter, double lat, double lon, Globe globe, DrawContext dc)
	{	/**Calculate the longitude angle from a distance in meter */
		Position position=new Position(Position.fromDegrees(lat, lon),0);
		Angle a=Angle.fromDegrees(1);
		Position addpos = new Position(position.getLatitude(), position.getLongitude().add(a), 0);		
		double dist= (double)Math.round((LatLon.ellipsoidalDistance(position, addpos, 6378100, 6356800)));
		Angle xres= a.multiply(meter).divide(dist);
		return xres;
	} 
}
