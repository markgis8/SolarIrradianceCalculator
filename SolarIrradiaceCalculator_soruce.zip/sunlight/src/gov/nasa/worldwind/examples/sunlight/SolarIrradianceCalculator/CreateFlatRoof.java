package gov.nasa.worldwind.examples.sunlight.SolarIrradianceCalculator;

import gov.nasa.worldwind.WorldWindow;
import gov.nasa.worldwind.geom.Position;
import gov.nasa.worldwind.globes.Globe;
import gov.nasa.worldwind.render.BasicShapeAttributes;
import gov.nasa.worldwind.render.DrawContext;
import gov.nasa.worldwind.render.ExtrudedPolygon;
import gov.nasa.worldwind.render.Material;
import gov.nasa.worldwind.render.ShapeAttributes;
import gov.nasa.worldwindx.examples.LayerPanel;

import java.awt.Color;
import java.util.ArrayList;
/**
 * Copyright (C) 2001 United States Government
 * as represented by the Administrator of the
 * National Aeronautics and Space Administration.
 * All Rights Reserved.
 * @author  Marco Piragnolo
 * Cirgeo, University of Padua, francesco.pirotti@unipd.it, marco.piragnolo@unipd.it
 * @version 0.1  2014-29-05 11:46
 */

//flat roof	
public class CreateFlatRoof extends Building{
/** Create a building with a flat roof*/
		public CreateFlatRoof(double lat, double lon, double lenght,
				double width, double height, double slope, int aspect, int aspectSide,
				Globe globe, WorldWindow wwd, LayerPanel layerPanel, DrawContext dc) 
		{
			super(lat, lon, lenght, width, height, slope, aspect,  aspectSide, globe, wwd, layerPanel, dc);
			// TODO Auto-generated constructor stub
            // Create and set an attribute bundle.
            ShapeAttributes sideAttributes = new BasicShapeAttributes();
            sideAttributes.setInteriorMaterial(new Material(new Color(255, 206, 156))); ;            
            sideAttributes.setOutlineOpacity(1);
            sideAttributes.setInteriorOpacity(1);
            sideAttributes.setOutlineMaterial(Material.BLACK);
            sideAttributes.setOutlineWidth(2);
            sideAttributes.setDrawOutline(true);
            sideAttributes.setDrawInterior(true);
            sideAttributes.setEnableLighting(true);   
            
            ShapeAttributes capAttributes = new BasicShapeAttributes(sideAttributes);
            capAttributes.setInteriorMaterial(Material.ORANGE);           
            capAttributes.setInteriorOpacity(1); 
			
            ArrayList<Position> positions1cal = new ArrayList<Position>(); 
            MeterToAngle meta =new MeterToAngle();
            Position baseA = new Position(Position.fromDegrees(lat, lon), height);                       
            Position posizB= new Position(baseA.getLatitude(), baseA.getLongitude().add(meta.lonMetersAngle(lenght, lat, lon,  globe, dc)), height);         
            Position posizC= new Position(baseA.getLatitude().add(meta.latMetersAngle(width, lat, lon,  globe, dc)), baseA.getLongitude().add(meta.lonMetersAngle(lenght, lat, lon,  globe, dc)), height);           
            Position posizD= new Position(baseA.getLatitude().add(meta.latMetersAngle(width, lat, lon,  globe, dc)), baseA.getLongitude(), height);
      
            positions1cal.add(baseA); 
            positions1cal.add(posizB);
            positions1cal.add(posizC);
            positions1cal.add(posizD);

            ExtrudedPolygon   poly1cal = new ExtrudedPolygon (positions1cal);
            float[] texCoords = new float[] {1,1, 1, 0, 0, 0, 0, 1};  
            poly1cal.setCapImageSource("images/roof35.jpg", texCoords, 4);
            poly1cal.setSideAttributes(sideAttributes);        
            poly1cal.setCapAttributes(capAttributes);
            poly1cal.setAltitudeMode(2);
            setPolygon(poly1cal); 
            
            //calculate the normal to the roof
            computeNormalBuilding(positions1cal.get(0), positions1cal.get(1), positions1cal.get(2), getBaricenter(positions1cal));	    	            
         }	
	}
