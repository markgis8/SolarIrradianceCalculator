package gov.nasa.worldwind.examples.sunlight.SolarIrradianceCalculator;

/**
 * Copyright (C) 2001 United States Government
 * as represented by the Administrator of the
 * National Aeronautics and Space Administration.
 * All Rights Reserved.
 * @author  Marco Piragnolo, Roberto Carbone
 * Cirgeo, University of Padua, francesco.pirotti@unipd.it, marco.piragnolo@unipd.it
 * @version 0.1  2014-29-05 11:46
 */

import gov.nasa.worldwind.WorldWindow;
import gov.nasa.worldwind.examples.sunlight.RectangularNormalTessellator;
import gov.nasa.worldwind.geom.Position;
import gov.nasa.worldwind.globes.Globe;
import gov.nasa.worldwind.layers.Layer;
import gov.nasa.worldwind.layers.RenderableLayer;
import gov.nasa.worldwind.render.DrawContext;
import gov.nasa.worldwind.view.orbit.OrbitView;
import gov.nasa.worldwindx.examples.LayerPanel;

import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.util.Hashtable;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTextArea;
import javax.swing.border.CompoundBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class MakeMenu {
	/**create the menu to create the scenario*/
    private JButton buildingButton;
    private JButton ghostButton;
    private JButton clearGhost;
    private JButton computeButton;
    private JSlider rSlopeSlider;
    private JSlider rAspectSlider;
    private JSlider rNumberSlider;
    private JSlider cloudSlider;
    private JTextArea cellSize ;
    private JTextArea yWide;
    private JTextArea xWide;
    private JTextArea roofL;
    private JTextArea roofW;
    private JTextArea roofH;
	private RenderableLayer renderableLayer;
	private LayerPanel layerPanel;
	private Globe globe;
	private DrawContext dc;
	private WorldWindow wwd;
	private int slope;
	private int aspect;
	private int numshee;
	private int cloud;
	private JLabel slopeTextLabel;
	private JLabel cloudTextLabel;
	private JLabel aspectTextLabel;
	private double lenght;
	private double width;
	private double height;
	private double xm;
	private int xgrid;
	private int ygrid;
	
    private JPanel pRho;
    public JComboBox menuRho;
    private double rho;

	
	private Thread calculationDispatchThread;
	private Position previousCurrentPosition;
	
	
	public JPanel roofPanel()
	{		
		return layerPanel;		
	}
	
	public double getRho() 
	{
		return rho;
	}
	
	public void setRho(String material) {
		/** set the prevalent material in the area to compute the reflection*/
		switch (material){
		case "No reflection": rho = 0;break;
		case "Dirt road": rho = 0.04;break;
		case "Asphalt road": rho = 0.1;break;
		case "Conifers": rho = 0.07;break;
		case "Broad-leaf trees": rho = 0.26;break;
		case "Grass (dry+green)": rho = 0.23;break;
		case "Loam": rho = 0.14;break;
		case "Roof": rho = 0.13;break;
		case "Concreete": rho = 0.22;break;
		case "Stones, gravel": rho = 0.2;break;
		case "Snow": rho = 0.75;break;
		case "Water": rho = 0.07;break;
		case "Dark-colored building": rho = 0.27;break;
		case "White-colored building": rho = 0.6;break;
		}
	}	

	public JPanel makeMenu(final RenderableLayer renderableLayer, final LayerPanel layerPanel, final Globe globe, final WorldWindow wwd, final Position crossPosition)
    {	/**create the menu*/
		this.renderableLayer=renderableLayer;
		this.layerPanel=layerPanel;
		this.globe=globe;
		this.wwd=wwd;  
        JPanel controlPanel = new JPanel(new GridLayout());
        controlPanel.setBorder(
        new CompoundBorder(BorderFactory.createEmptyBorder(9, 9, 9, 9),
        new TitledBorder("Control panel")));                 
       
        final JTextArea cellSize = new JTextArea(1, 3);
        cellSize.setEnabled(true);
        cellSize.setToolTipText("Cell size in meters");   
        cellSize.setName("cellSize");    
        //
        // Add key listener to change the TAB behaviour in
        // JTextArea to transfer focus to other component forward
        // or backward.
        //
        cellSize.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_TAB) {
                    if (e.getModifiers() > 0) {
                    	cellSize.transferFocusBackward();
                    } else {
                    	cellSize.transferFocus();
                    }
                    e.consume();
                }
            }
        });
        
        final JTextArea xWide = new JTextArea(1, 3);
        xWide.setEnabled(true);
        xWide.setToolTipText("number of cells in x axis");   
        xWide.setName("xwide");    
        //
        // Add key listener to change the TAB behaviour in
        // JTextArea to transfer focus to other component forward
        // or backward.
        //
        xWide.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_TAB) {
                    if (e.getModifiers() > 0) {
                    	xWide.transferFocusBackward();
                    } else {
                    	xWide.transferFocus();
                    }
                    e.consume();
                }
            }
        });
        
        final JTextArea yWide = new JTextArea(1, 3);
        yWide.setEnabled(true);
        yWide.setToolTipText("number of cells in y axis");   
        yWide.setName("ywide");    
        //
        // Add key listener to change the TAB behaviour in
        // JTextArea to transfer focus to other component forward
        // or backward.
        //
        yWide.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_TAB) {
                    if (e.getModifiers() > 0) {
                    	yWide.transferFocusBackward();
                    } else {
                    	yWide.transferFocus();
                    }
                    e.consume();
                }
            }
        });
        
       
        // grid button
        JPanel buttonPanelGrid = new JPanel(new GridLayout(0, 1, 0, 0));
        buttonPanelGrid.setBorder(BorderFactory.createEmptyBorder(6, 6, 6, 6));    
        final Grid grid = new Grid (crossPosition.getLatitude().getDegrees(), crossPosition.getLongitude().getDegrees(), globe, wwd, this.layerPanel);
      
        // material
        String[] rhoString = {"No reflection", "Dirt road","Asphalt road","Conifers","Broad-leaf trees","Grass (dry+green)","Loam","Roof","Concreete","Stones, gravel","Snow","Water","Dark-colored building","white-colored building"};
        menuRho = new JComboBox (rhoString);
        pRho = new JPanel();
        pRho.setLayout(new FlowLayout());
        pRho.add(menuRho);
       
        ghostButton = new JButton("Ghost grid"); 
        ghostButton.addActionListener(new ActionListener()
        {	
			public void actionPerformed(ActionEvent actionEvent)
            {  	
            	xm=Double.parseDouble(cellSize.getText());
        		xgrid=Integer.parseInt(xWide.getText());
        		ygrid=Integer.parseInt(yWide.getText());   
        	               		  
                OrbitView view = (OrbitView)wwd.getView();
                Position crossPosition = view.getCenterPosition();
      
                grid.ghostLayer(xm, xgrid, ygrid, crossPosition.getLatitude().getDegrees(), crossPosition.getLongitude().getDegrees());	       		         
            }
        });
        
        clearGhost = new JButton("Clear ghost ");
        clearGhost.addActionListener(new ActionListener()
        {
			public void actionPerformed(ActionEvent actionEvent)
            {  	
            Layer remghost1 =  wwd.getModel().getLayers().getLayerByName("Ghost area");
            Layer remghost2 =  wwd.getModel().getLayers().getLayerByName("Ghost grid");
            wwd.getModel().getLayers().remove(remghost1);
            wwd.getModel().getLayers().remove(remghost2);
            }
        });
        
        computeButton = new JButton("Compute"); 

        computeButton.addActionListener(new ActionListener()
        {			
			public void actionPerformed(ActionEvent actionEvent)
            {  	
            	xm=Double.parseDouble(cellSize.getText());
        		xgrid=Integer.parseInt(xWide.getText());
        		ygrid=Integer.parseInt(yWide.getText());
        		setRho((String)menuRho.getSelectedItem());
        		
                OrbitView view = (OrbitView)wwd.getView();
                Position crossPosition = view.getCenterPosition();   
       
                grid.createGrid(xm, xgrid, ygrid, crossPosition.getLatitude().getDegrees(), crossPosition.getLongitude().getDegrees(), getRho(), cloud);	       		                                      
            }
        });
        
        buttonPanelGrid.add(ghostButton); 
        buttonPanelGrid.add(clearGhost);
        buttonPanelGrid.add(computeButton);  
       
        final JTextArea roofL = new JTextArea(1, 3);
        roofL.setEnabled(true);
        roofL.setToolTipText("Lenght");   
        roofL.setName("lenght");    
        //
        // Add key listener to change the TAB behaviour in
        // JTextArea to transfer focus to other component forward
        // or backward.
        //
        roofL.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_TAB) {
                    if (e.getModifiers() > 0) {
                    	roofL.transferFocusBackward();
                    } else {
                    	roofL.transferFocus();
                    }
                    e.consume();
                }
            }
        });
        
        final JTextArea roofW = new JTextArea(1, 3);
        roofW.setEnabled(true);
        roofW.setToolTipText("Width");
        roofW.setName("width");   
        //
        // Add key listener to change the TAB behaviour in
        // JTextArea to transfer focus to other component forward
        // or backward.
        //
        roofW.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_TAB) {
                    if (e.getModifiers() > 0) {
                    	roofW.transferFocusBackward();
                    } else {
                    	roofW.transferFocus();
                    }
                    e.consume();
                }
            }
        });
        
        final JTextArea roofH = new JTextArea(1, 3);
        roofH.setEnabled(true);
        roofH.setToolTipText("Height");
        roofH.setName("height");
        //
        // Add key listener to change the TAB behaviour in
        // JTextArea to transfer focus to other component forward
        // or backward.
        //
        roofH.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_TAB) {
                    if (e.getModifiers() > 0) {
                    	roofH.transferFocusBackward();
                    } else {
                    	roofH.transferFocus();
                    }
                    e.consume();
                }
            }
        });
        
        //Slope Slider
        rSlopeSlider = new JSlider(JSlider.VERTICAL);
        rSlopeSlider.setToolTipText("Slope degree");
        rSlopeSlider.setPaintLabels(true);
        rSlopeSlider.setPaintTicks(true);
        rSlopeSlider.setMaximum(45);
        rSlopeSlider.setMinorTickSpacing(1);      
        rSlopeSlider.setMajorTickSpacing(5);
        rSlopeSlider.setValue(0);
        rSlopeSlider.setSnapToTicks(true); 
        rSlopeSlider.addMouseMotionListener(new MouseMotionAdapter() {				
		});					
		rSlopeSlider.addChangeListener(new ChangeListener(){
			@Override
			public void stateChanged(ChangeEvent e) {
				// TODO Auto-generated method stub
				rSlopeSlider = (JSlider)e.getSource();				
				slope=((JSlider)e.getSource()).getValue();
				slopeTextLabel.setText("Angle: "+slope);
			}
		});
		slopeTextLabel = (new JLabel("Angle: "+slope)); 
		
        //Aspect Slider
        rAspectSlider = new JSlider(JSlider.VERTICAL);
        rAspectSlider.setToolTipText("Aspect of the roof");
        rAspectSlider.setPaintLabels(true);
        rAspectSlider.setPaintTicks(true);
        rAspectSlider.setValue(0);       
        Hashtable<Integer, JLabel> labelE = new Hashtable<Integer, JLabel>();
        labelE.put(new Integer(180), new JLabel("North"));      
        labelE.put(new Integer(90), new JLabel("East"));
        labelE.put(new Integer(0), new JLabel("South"));
        labelE.put(new Integer(270), new JLabel("West"));
		rAspectSlider.setLabelTable(labelE);
        rAspectSlider.setMinimum(0);
        rAspectSlider.setMaximum(270);
        rAspectSlider.setMinorTickSpacing(90);    
        rAspectSlider.setMajorTickSpacing(90);  
        rAspectSlider.setInverted(true);
        rAspectSlider.setSnapToTicks(true);        
        rAspectSlider.addMouseMotionListener(new MouseMotionAdapter() {				
		});	
		rAspectSlider.addChangeListener(new ChangeListener(){
			@Override
			public void stateChanged(ChangeEvent e) {
				// TODO Auto-generated method stub
				rAspectSlider = (JSlider)e.getSource();			
				aspect=((JSlider)e.getSource()).getValue();
			}
		});
        
        //Number of roofing sheets Slider
        rNumberSlider = new JSlider(JSlider.VERTICAL);
        rNumberSlider.setToolTipText("Number of roofing sheets");
        rNumberSlider.setPaintLabels(true);
        rNumberSlider.setPaintTicks(true);
        rNumberSlider.setValue(0);
        Hashtable<Integer, JLabel> labelN = new Hashtable<Integer, JLabel>();
        labelN.put(new Integer(0), new JLabel("1"));  
        labelN.put(new Integer(2), new JLabel("2"));  
        labelN.put(new Integer(4), new JLabel("4"));  
        rNumberSlider.setLabelTable(labelN);
        rNumberSlider.setMinimum(0);
        rNumberSlider.setMaximum(4);
        rNumberSlider.setMinorTickSpacing(2);    
        rNumberSlider.setMajorTickSpacing(2);  
        rNumberSlider.setSnapToTicks(true);        
        rNumberSlider.addMouseMotionListener(new MouseMotionAdapter() {				
		});			
		rNumberSlider.addChangeListener(new ChangeListener(){
			@Override
			public void stateChanged(ChangeEvent e) {
				// TODO Auto-generated method stub
				rNumberSlider = (JSlider)e.getSource();			
				numshee=((JSlider)e.getSource()).getValue();
			}
		});
        
        //Number of roofing sheets Slider
        cloudSlider = new JSlider(JSlider.HORIZONTAL);
        cloudSlider .setToolTipText("Cloud coverage");
        cloudSlider.setPaintLabels(true);
        cloudSlider.setPaintTicks(true);
        cloudSlider.setValue(0);
        Hashtable<Integer, JLabel> labelC = new Hashtable<Integer, JLabel>();
        labelC.put(new Integer(0), new JLabel("No cloud"));   
        labelC.put(new Integer(100), new JLabel("Covered"));  
        cloudSlider.setLabelTable(labelC);
        cloudSlider.setMinimum(0);
        cloudSlider.setMaximum(100);
        cloudSlider.setMinorTickSpacing(5);    
        cloudSlider.setMajorTickSpacing(10);      
        cloudSlider.setSnapToTicks(true);        
        cloudSlider.addMouseMotionListener(new MouseMotionAdapter() {				
		});			
        cloudSlider.addChangeListener(new ChangeListener(){
			@Override
			public void stateChanged(ChangeEvent e) {
				// TODO Auto-generated method stub
				cloudSlider = (JSlider)e.getSource();			
				cloud=((JSlider)e.getSource()).getValue();
				cloudTextLabel.setText("Cloud % : "+cloud);
			}
		});
        cloudTextLabel = (new JLabel("Cloud % : "+cloud)); 
      
		
        // Build button
        JPanel buttonPanelBuilding = new JPanel(new GridLayout(0, 1, 0, 0));
        buttonPanelBuilding.setBorder(BorderFactory.createEmptyBorder(6, 6, 6, 6));
        buildingButton = new JButton("Build"); 
        final Building building = new Building(crossPosition.getLatitude().getDegrees(), crossPosition.getLongitude().getDegrees(), lenght, width, height, slope, aspect, 0, globe, wwd, layerPanel, dc);
        building.inserBuildingtLayer();
        //building.inserNormalRoofLayer(); 
        buildingButton.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent actionEvent)
            {  	
            	lenght=Double.parseDouble(roofL.getText());
        		width=Double.parseDouble(roofW.getText());
        		height=Double.parseDouble(roofH.getText());    	
        	   	
                Globe globe=wwd.getModel().getGlobe();   
                OrbitView view = (OrbitView)wwd.getView();
                Position crossPosition = view.getCenterPosition();
               
                switch(numshee){
                	case 0: if(slope==0)
                				{                   				               				          
                				CreateFlatRoof flatroof = new CreateFlatRoof(crossPosition.getLatitude().getDegrees(), crossPosition.getLongitude().getDegrees(), lenght, width, height, slope, aspect, 0, globe, wwd, layerPanel, dc);              				               				           		               				   
                				flatroof.insertBuilding(flatroof.getPolygon()/*polygon*/); 
                				flatroof.insertBuildingHash(flatroof);
                				}
                			else{
                				CreateShedRoof shedroof = new CreateShedRoof(crossPosition.getLatitude().getDegrees(), crossPosition.getLongitude().getDegrees(), lenght, width, height, slope, aspect, (int) aspect, globe, wwd, layerPanel, dc);           
                				shedroof.insertBuilding(shedroof.getPolygon());
                				shedroof.insertBuildingHash(shedroof);
                				}
                		break;
                	case 2:	  						
                			if(aspect==0 || aspect==180) 
                			{            			
                			CreateGableNorth   sideGNorth= new CreateGableNorth(crossPosition.getLatitude().getDegrees(), crossPosition.getLongitude().getDegrees(), lenght, width, height, slope, aspect, 180, globe, wwd, layerPanel, dc);	    					
    						sideGNorth.insertBuilding(sideGNorth.getPolygon());
    						sideGNorth.insertBuildingHash(sideGNorth);   						

    						CreateGableSouth  sideGSouth= new CreateGableSouth (crossPosition.getLatitude().getDegrees(), crossPosition.getLongitude().getDegrees(), lenght, width, height, slope, aspect, 0, globe, wwd, layerPanel, dc);	    					
    						sideGSouth.insertBuilding(sideGSouth.getPolygon());
    						sideGSouth.insertBuildingHash(sideGSouth);
                			}
                			else if(aspect==90 || aspect==270)
                			{
    						CreateGableEast  sideGEast= new CreateGableEast(crossPosition.getLatitude().getDegrees(), crossPosition.getLongitude().getDegrees(), lenght, width, height, slope, aspect, 90, globe, wwd, layerPanel, dc);	    					
    						sideGEast.insertBuilding(sideGEast.getPolygon());
    						sideGEast.insertBuildingHash(sideGEast);

    						CreateGableWest  sideGWest= new CreateGableWest (crossPosition.getLatitude().getDegrees(), crossPosition.getLongitude().getDegrees(), lenght, width, height, slope, aspect, 270, globe, wwd, layerPanel, dc);	    					
    						sideGWest.insertBuilding(sideGWest.getPolygon());
    						sideGWest.insertBuildingHash(sideGWest);
                			}
                		break;
                	case 4:	               			   						
    						CreateHippedNorth sidenorth= new CreateHippedNorth(crossPosition.getLatitude().getDegrees(), crossPosition.getLongitude().getDegrees(), lenght, width, height, slope, aspect, 180, globe, wwd, layerPanel, dc);	    					
    						sidenorth.insertBuilding(sidenorth.getPolygon());
    						sidenorth.insertBuildingHash(sidenorth);    						
    						
    						CreateHippedSouth sidesouth= new CreateHippedSouth(crossPosition.getLatitude().getDegrees(), crossPosition.getLongitude().getDegrees(), lenght, width, height, slope, aspect, 0, globe, wwd, layerPanel, dc);	
    						sidesouth.insertBuilding(sidesouth.getPolygon());
    						sidesouth.insertBuildingHash(sidesouth);     			
    						
    						CreateHippedEast sideeast= new CreateHippedEast(crossPosition.getLatitude().getDegrees(), crossPosition.getLongitude().getDegrees(), lenght, width, height, slope, aspect, 90, globe, wwd, layerPanel, dc);	   					
    						sideeast.insertBuilding(sideeast.getPolygon()); 
    						sideeast.insertBuildingHash(sideeast);    						   						
    						
    						CreateHippedWest sidewest= new CreateHippedWest(crossPosition.getLatitude().getDegrees(), crossPosition.getLongitude().getDegrees(), lenght, width, height, slope, aspect, 270, globe, wwd, layerPanel, dc);	
    						sidewest.insertBuilding(sidewest.getPolygon());   						 
    						sidewest.insertBuildingHash(sidewest);   						
                		break;
                }  
            }
        });
        buttonPanelBuilding.add(buildingButton);          
        
        // Panel assembly  
        controlPanel.setLayout(new GridBagLayout());  
        GridBagConstraints constr01 = new GridBagConstraints();
        constr01.gridy=0;
        constr01.gridx=1;
        constr01.insets=new Insets(5,1,5,1);
        controlPanel.add(new JLabel("Set size (meter)"), constr01);
        
        GridBagConstraints constr10 = new GridBagConstraints();
        constr10.gridy=1;
        constr10.gridx=0;
        constr10.insets=new Insets(5,1,1,1);
        controlPanel.add(new JLabel("Lenght"), constr10);
        
        GridBagConstraints constr11 = new GridBagConstraints();
        constr11.gridy=1;
        constr11.gridx=1;
        constr11.insets=new Insets(5,1,1,1);
        controlPanel.add(new JLabel("Width"), constr11);
        
        GridBagConstraints constr12 = new GridBagConstraints();
        constr12.gridy=1;
        constr12.gridx=2;
        constr12.insets=new Insets(5,1,1,1);
        controlPanel.add(new JLabel("Height"), constr12);
        
        GridBagConstraints constr20 = new GridBagConstraints();
        constr20.gridy=2;
        constr20.gridx=0;
        constr20.insets=new Insets(3,1,1,1);
        controlPanel.add(roofL, constr20);
            
        GridBagConstraints constr21 = new GridBagConstraints();
        constr21.gridy=2;
        constr21.gridx=1;
        constr21.insets=new Insets(3,1,1,1);
        controlPanel.add(roofW, constr21);
           
        GridBagConstraints constr22 = new GridBagConstraints();
        constr22.gridy=2;
        constr22.gridx=2;
        constr22.insets=new Insets(3,1,1,1);
        controlPanel.add(roofH, constr22);
              
        GridBagConstraints constr31 = new GridBagConstraints();
        constr31.gridy=3;
        constr31.gridx=1;
        constr31.insets=new Insets(10,1,10,1);
        controlPanel.add(new JLabel("Set the roof's parameters"), constr31);
        
        GridBagConstraints constr40 = new GridBagConstraints();
        constr40.gridy=4;
        constr40.gridx=0;
        constr40.insets=new Insets(5,2,1,2);
        controlPanel.add(new JLabel("N sheets"), constr40);
        
        GridBagConstraints constr41 = new GridBagConstraints();
        constr41.gridy=4;
        constr41.gridx=1;
        constr41.insets=new Insets(1,2,1,2);
        controlPanel.add(new JLabel("Slope"), constr41);
        
        GridBagConstraints constr42 = new GridBagConstraints();
        constr42.gridy=4;
        constr42.gridx=2;
        constr42.insets=new Insets(1,2,1,2);
        controlPanel.add(new JLabel("Aspect"), constr42);
        
        GridBagConstraints constr50 = new GridBagConstraints();
        constr50.gridy=5;
        constr50.gridx=0;
        constr50.insets=new Insets(3,2,1,2);
        controlPanel.add(rNumberSlider, constr50);
        
        GridBagConstraints constr51 = new GridBagConstraints();
        constr51.gridy=5;
        constr51.gridx=1;
        constr51.insets=new Insets(3,2,1,2);
        controlPanel.add(rSlopeSlider, constr51);
        
        GridBagConstraints constr52 = new GridBagConstraints();
        constr52.gridy=5;
        constr52.gridx=2;
        constr52.insets=new Insets(3,2,1,2);
        controlPanel.add(rAspectSlider, constr52);
        
        GridBagConstraints constr61 = new GridBagConstraints();
        constr61.gridy=6;
        constr61.gridx=1;
        constr61.insets=new Insets(3,2,1,2);
        controlPanel.add(slopeTextLabel, constr61);
        
        GridBagConstraints constr72 = new GridBagConstraints();
        constr72.gridy=7;
        constr72.gridx=2;
        constr72.insets=new Insets(5,2,5,2);
        controlPanel.add(buildingButton, constr72);
        
        GridBagConstraints constr81 = new GridBagConstraints();
        constr81.gridy=8;
        constr81.gridx=1;
        constr81.insets=new Insets(10,2,5,2);
        controlPanel.add(new JLabel("Cloud coverage"), constr81);
      
        GridBagConstraints constr91 = new GridBagConstraints();
        constr91.gridy=9;
        constr91.gridx=1;
        constr91.insets=new Insets(10,2,5,2);
        controlPanel.add(cloudSlider, constr91);
        
        GridBagConstraints constr92 = new GridBagConstraints();
        constr92.gridy=9;
        constr92.gridx=2;
        constr92.insets=new Insets(5,2,5,2);
        controlPanel.add(cloudTextLabel, constr92);
        
        GridBagConstraints constr101 = new GridBagConstraints();
        constr101.gridy=10;
        constr101.gridx=1;
        constr101.insets=new Insets(10,2,5,2);
        controlPanel.add(new JLabel("Prevalent ground material"), constr101);

        GridBagConstraints constr111 = new GridBagConstraints();
        constr111.gridy=11;
        constr111.gridx=1;
        constr111.insets=new Insets(5,2,5,2);
        controlPanel.add(pRho,constr111);

        GridBagConstraints constr120 = new GridBagConstraints();
        constr120.gridy=12;
        constr120.gridx=0;
        constr120.insets=new Insets(5,2,5,2);
        controlPanel.add(new JLabel("cell size"), constr120);
        
        GridBagConstraints constr121 = new GridBagConstraints();
        constr121.gridy=12;
        constr121.gridx=1;
        constr121.insets=new Insets(5,2,5,2);
        controlPanel.add(new JLabel("X wide"), constr121);
        
        GridBagConstraints constr122 = new GridBagConstraints();
        constr122.gridy=12;
        constr122.gridx=2;
        constr122.insets=new Insets(5,2,5,2);
        controlPanel.add(new JLabel("Y wide"), constr122);
        
               
        GridBagConstraints constr130 = new GridBagConstraints();
        constr130.gridy=13;
        constr130.gridx=0;
        constr130.insets=new Insets(5,2,5,2);
        controlPanel.add(cellSize, constr130);
        
        GridBagConstraints constr131 = new GridBagConstraints();
        constr131.gridy=13;
        constr131.gridx=1;
        constr131.insets=new Insets(5,2,5,2);
        controlPanel.add(xWide, constr131);
        
        GridBagConstraints constr132 = new GridBagConstraints();
        constr132.gridy=13;
        constr132.gridx=2;
        constr132.insets=new Insets(5,2,5,2);
        controlPanel.add(yWide, constr132);
        
        GridBagConstraints constr140 = new GridBagConstraints();
        constr140.gridy=14;
        constr140.gridx=0;
        constr140.insets=new Insets(5,2,5,2);
        controlPanel.add(ghostButton, constr140);
     
        
        GridBagConstraints constr141 = new GridBagConstraints();
        constr141.gridy=14;
        constr141.gridx=1;
        constr141.insets=new Insets(5,2,5,2);
        controlPanel.add(clearGhost, constr141);
       
     
        GridBagConstraints constr142 = new GridBagConstraints();
        constr142.gridy=14;
        constr142.gridx=2;
        constr142.insets=new Insets(5,2,5,2);
        controlPanel.add(computeButton, constr142);
        
      
        return controlPanel;
    }		
	
    public Position mousePos()
    { 
    	Position pos = null;
    	 wwd.getInputHandler().addMouseListener(new MouseAdapter()
        {
            public void mouseClicked(MouseEvent mouseEvent)
            {
                // Control-Click cancels any currently running operation.
                if ((mouseEvent.getModifiers() & ActionEvent.CTRL_MASK) != 0)
                {
                    if (calculationDispatchThread != null && calculationDispatchThread.isAlive())
                        calculationDispatchThread.interrupt();
                    return;
                }

                // Alt-Click repeats the most recent calculations.
                if ((mouseEvent.getModifiers() & ActionEvent.ALT_MASK) != 0)
                {
                    if (previousCurrentPosition == null)
                        return;

                    mouseEvent.consume(); // tell the rest of WW that this event has been processed

                    return;
                }

                // Perform the intersection tests in response to Shift-Click.
                if ((mouseEvent.getModifiers() & ActionEvent.SHIFT_MASK) == 0)
                    return;

                mouseEvent.consume(); // tell the rest of WW that this event has been processed

                final Position pos = wwd.getCurrentPosition();
                if (pos == null)
                    return;
            }
        });
		return pos;
    }    
}