package gov.nasa.worldwind.examples.sunlight.SolarIrradianceCalculator;


import gov.nasa.worldwind.WorldWindow;
import gov.nasa.worldwind.geom.Angle;
import gov.nasa.worldwind.geom.LatLon;
import gov.nasa.worldwind.geom.Position;
import gov.nasa.worldwind.geom.Vec4;
import gov.nasa.worldwind.globes.Globe;
import gov.nasa.worldwindx.examples.LayerPanel;

/**
 * Copyright (C) 2001 United States Government
 * as represented by the Administrator of the
 * National Aeronautics and Space Administration.
 * All Rights Reserved.
 * @author  Marco Piragnolo
 * Cirgeo, University of Padua, francesco.pirotti@unipd.it, marco.piragnolo@unipd.it
 * @version 0.1  2014-29-05 11:46
 */

public class AspectSlopeTerrCalc {
	
	private Globe globe;     
    private Angle aspect;
    private Angle slope;
	private Position position;
	private WorldWindow wwd;
	protected LayerPanel layerPanel;
	
	protected AspectSlopeTerrCalc(Globe globe, WorldWindow wwd, Position terrPosition)
    {	/**compute slope and aspect of terrain*/
		this.wwd=wwd;
		this.globe=globe;
    	this.position= terrPosition;
        // Establish three points that define a triangle around the center position 
        // to be used for determining the slope and aspect of the terrain (roughly 10 meters per side)
        LatLon n1 = LatLon.rhumbEndPosition(position, Angle.ZERO, Angle.fromDegrees(-0.00005));     // due south
        LatLon n2 = LatLon.rhumbEndPosition(n1, Angle.fromDegrees(-60), Angle.fromDegrees(0.0001)); // northwest
        LatLon n3 = LatLon.rhumbEndPosition(n1, Angle.fromDegrees(60), Angle.fromDegrees(0.0001));  // northeast
    	
    	// Get the cartesian coords for the points
        Vec4 p1 = globe.computePointFromPosition(
                new Position(n1, globe.getElevation(n1.getLatitude(), n1.getLongitude())));
        Vec4 p2 = globe.computePointFromPosition(
                new Position(n2, globe.getElevation(n2.getLatitude(), n2.getLongitude())));
        Vec4 p3 = globe.computePointFromPosition(
                new Position(n3, globe.getElevation(n3.getLatitude(), n3.getLongitude())));

        // Compute an upward pointing normal of the triangle and other essential vectors
        Vec4 terrainNormal = p1.subtract3(p3).cross3(
                p1.subtract3(p2)).normalize3();
        Vec4 surfaceNormal = this.globe.computeSurfaceNormalAtLocation(position.getLatitude(),
                position.getLongitude());
        Vec4 north = this.globe.computeNorthPointingTangentAtLocation(position.getLatitude(),
                position.getLongitude());
      
        // Compute terrain slope -- the delta between surface normal and terrain normal
        slope = terrainNormal.angleBetween3(surfaceNormal);

        // Compute the terrain aspect -- get a perpendicular vector projected onto
        // surface normal which is in the same plane as the north vector. Get delta
        // with north vector and use  dot product to determine aspect angle's sign (+/- 180)
        Vec4 perpendicular = terrainNormal.perpendicularTo3(surfaceNormal);
        aspect = perpendicular.angleBetween3(north);
        double direction = Math.signum(-surfaceNormal.cross3(north).dot3(perpendicular));
        aspect = aspect.multiply(direction); 
        //compute from south
        aspect= aspect.subtractDegrees(180).multiply(-1);
    }
	
	public Angle getSlopeTerrain()
	{	return slope;}
	
	public Angle getAspectTerrain()
	{	return aspect;}

}
