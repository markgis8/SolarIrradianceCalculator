/*
Copyright (C) 2001, 2008 United States Government
as represented by the Administrator of the
National Aeronautics and Space Administration.
All Rights Reserved.
*/
package gov.nasa.worldwind.examples.sunlight.SolarIrradianceCalculator;


import gov.nasa.worldwind.layers.CrosshairLayer;
import gov.nasa.worldwind.layers.GeometryGridLayer;
import gov.nasa.worldwind.layers.RenderableLayer;
import gov.nasa.worldwind.Configuration;
import gov.nasa.worldwind.WorldWindow;
import gov.nasa.worldwind.avlist.AVKey;
import gov.nasa.worldwind.event.*;
import gov.nasa.worldwind.examples.sunlight.RectangularNormalTessellator;
import gov.nasa.worldwindx.examples.ApplicationTemplate;
import gov.nasa.worldwind.geom.*;
import gov.nasa.worldwind.globes.Globe;
import gov.nasa.worldwind.layers.Earth.UTMBaseGraticuleLayer;
import gov.nasa.worldwind.layers.*;
import gov.nasa.worldwind.render.DrawContext;
import gov.nasa.worldwind.terrain.HighResolutionTerrain;
import gov.nasa.worldwind.terrain.Terrain;
import gov.nasa.worldwind.view.orbit.OrbitView;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Calendar;
import java.util.GregorianCalendar;


/**
 * Copyright (C) 2001 United States Government
 * as represented by the Administrator of the
 * National Aeronautics and Space Administration.
 * All Rights Reserved.
 * @author Patrick Murris, adapted by Francesco Pirotti, Marco Piragnolo, Roberto Carbone
 * Cirgeo, University of Padua, francesco.pirotti@unipd.it, marco.piragnolo@unipd.it
 * @version $Id$
 * @see RectangularNormalTessellator
 * @see AtmosphereLayer, AtmosphericScatteringComputer
 * @see LensFlareLayer
 * @see BasicSunPositionProvider, SunCalculator
 * @version 0.1  2014-29-05 11:46
 */
public class SunShading extends ApplicationTemplate
{
    public static class AppFrame extends ApplicationTemplate.AppFrame
    { 
        private JCheckBox enableCheckBox;
        private JCheckBox enableGrid;
        private JCheckBox enableGridf;
        private JButton colorButton;
        private JButton ambientButton;
        private JRadioButton relativeRadioButton;
        private JRadioButton absoluteRadioButton;
        private JSlider azimuthSlider;
        private JSlider elevationSlider;
        private JLabel textLabel;
        static HighResolutionTerrain terrain;
        static Terrain terrain2;
        static Globe globe;
        static WorldWindow wwd;
        static AppFrame appFrame;
        public JComboBox menuGiorni;
        private JPanel p1;
        public JComboBox menuMesi;
        public JTextField anno;
        public JComboBox menuOre;
        private JPanel p2;
        public JComboBox menuMinuti;
        public JComboBox menuTimeZone;
        private JPanel p3;
        private JButton computeButton;
        public static Calendar time = new GregorianCalendar();
        public AdvancedSunCalculator position;
        
        private GeometryGridLayer SgLt;  //FP
        private UTMBaseGraticuleLayer utmGraticuleLayer; //FP
        private RectangularNormalTessellator tessellator;
        private static LensFlareLayer lensFlareLayer;
        private AtmosphereLayer atmosphereLayer;
        private SunPositionProvider spp = new BasicSunPositionProvider();      
        private static ListObject listOfBuilding; 
        private static ListPosition listOfPosition; 
       
        
        public AppFrame()
        {
            super(true, true, false);
            Globe globe=getWwd().getModel().getGlobe();   
            AppFrame.globe=globe;
            OrbitView view = (OrbitView)getWwd().getView();
            Position centerPosition = view.getCenterPosition();          
            DrawContext drawing=(DrawContext) getWwd().getSceneController().getDrawContext();
            AppFrame.listOfBuilding= new ListObject(); 
            AppFrame.listOfPosition= new ListPosition();
            AppFrame.terrain = new HighResolutionTerrain(globe, 10d);   
            
            
            JFrame controlFrame = new JFrame();
            RenderableLayer renderableLayer = new RenderableLayer();
            insertBeforeCompass(getWwd(), new CrosshairLayer());
            
            getWwd().getModel().getLayers();
            MakeMenu menu = new MakeMenu();

            controlFrame.getContentPane().add(menu.makeMenu(renderableLayer, layerPanel, globe, getWwd(), centerPosition));
            controlFrame.pack();
            controlFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            controlFrame.setVisible(true);
         
            // Replace sky gradient with atmosphere layer
            this.atmosphereLayer = new AtmosphereLayer();
            for (int i = 0; i < this.getWwd().getModel().getLayers().size(); i++)
            {
                Layer l = this.getWwd().getModel().getLayers().get(i);
                if (l instanceof SkyGradientLayer)
                    this.getWwd().getModel().getLayers().set(i, this.atmosphereLayer);
            }
            // Add lens flare layer
            AppFrame.lensFlareLayer = LensFlareLayer.getPresetInstance(LensFlareLayer.PRESET_BOLD);
            this.getWwd().getModel().getLayers().add(AppFrame.lensFlareLayer);

            // Update layer panel
            this.getLayerPanel().update(getWwd());

            // Get tessellator
            this.tessellator = (RectangularNormalTessellator)getWwd().getModel().getGlobe().getTessellator();

            // Add control panel
            this.getLayerPanel().add(makeControlPanel(),  BorderLayout.SOUTH);

            // Add position listener to update light direction relative to the eye
            getWwd().addPositionListener(new PositionListener()
            {
                Vec4 eyePoint;
                public void moved(PositionEvent event)
                {
                    if (eyePoint == null || eyePoint.distanceTo3(getWwd().getView().getEyePoint()) > 1000)
                    {
                        updateCal();
                        eyePoint = getWwd().getView().getEyePoint();
                    }
                }
            });

            // Add one minute update timer
            Timer updateTimer = new Timer(60000, new ActionListener()
            {
                public void actionPerformed(ActionEvent event)
                {
                    updateCal();
                }
            });
            updateTimer.start();

            updatePanels();
            updateCal();
        }
        
        private JPanel makeControlPanel()
        {
            JPanel controlPanel = new JPanel();
            controlPanel.setLayout(new BoxLayout(controlPanel, BoxLayout.Y_AXIS));
            controlPanel.setBorder(new CompoundBorder(BorderFactory.createEmptyBorder(9, 9, 9, 9),
                    new TitledBorder("Sun Light")));
            controlPanel.setToolTipText("Set the Sun light direction and color");

            // Enable and Color
            final JPanel colorPanel = new JPanel(new GridLayout(0, 3, 0, 0));
            colorPanel.setBorder(BorderFactory.createEmptyBorder(6, 6, 6, 6));
            
            enableCheckBox = new JCheckBox("Enable");
            enableCheckBox.setSelected(true);
            enableCheckBox.addActionListener(new ActionListener()
            {
                public void actionPerformed(ActionEvent e)
                {
                    updatePanels();
                    updateCal();
                }
            });
            colorPanel.add(enableCheckBox);
            
            colorButton = new JButton("Light");
            colorButton.setBackground(this.tessellator.getLightColor());
            colorButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent event)
                {
                    Color c = JColorChooser.showDialog(colorPanel, "Choose a color...",
                        ((JButton)event.getSource()).getBackground());
                    if (c != null)
                    {
                        ((JButton)event.getSource()).setBackground(c);
                        updatePanels();
                        updateCal();
                    }
                }
            });
            colorPanel.add(colorButton);

            ambientButton = new JButton("Shade");
            ambientButton.setBackground(this.tessellator.getAmbientColor());
            ambientButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent event)
                {
                    Color c = JColorChooser.showDialog(colorPanel, "Choose a color...",
                        ((JButton)event.getSource()).getBackground());
                    if (c != null)
                    {
                        ((JButton)event.getSource()).setBackground(c);
                        updateCal();
                    }
                }
            });
            colorPanel.add(ambientButton);

            // Relative vs absolute Sun position
            final JPanel positionTypePanel = new JPanel(new GridLayout(0, 2, 0, 0));
            positionTypePanel.setBorder(BorderFactory.createEmptyBorder(6, 6, 6, 6));
            relativeRadioButton = new JRadioButton("Relative");
            relativeRadioButton.setSelected(false);
            relativeRadioButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent event)
                {
                    updatePanels();
                    //updateCal();
                }
            });
            positionTypePanel.add(relativeRadioButton);
            absoluteRadioButton = new JRadioButton("Absolute");
            absoluteRadioButton.setSelected(true);
            absoluteRadioButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent event)
                {
                    updatePanels();
                    updateCal();
                }
            });
            positionTypePanel.add(absoluteRadioButton);
            ButtonGroup group = new ButtonGroup();
            group.add(relativeRadioButton);
            group.add(absoluteRadioButton);

            
            // days
            String[] numGiorni = {"1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31"};
            menuGiorni = new JComboBox (numGiorni);
            p1 = new JPanel();
            p1.setLayout(new FlowLayout());
            p1.add(menuGiorni);
            // month
            String[] mesi = {"01","02","03","04","05","06","07","08","09","10","11","12"};
            menuMesi = new JComboBox (mesi);
            p1.add(menuMesi);
            //year
            anno = new JTextField (5);
            p1.add(anno);
            //hour
            String[] numOre = {"00","01","02","03","04","05","06","07","08","09","10","11","12","13","14","15","16","17","18","19","20","21","22","23"};
            menuOre = new JComboBox (numOre);
            p2 = new JPanel();
            p2.setLayout(new FlowLayout());
            p2.add(menuOre);
            //minute
            String[] minuti = {"00","01","02","03","04","05","06","07","08","09","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30",
            					"31","32","33","34","35","36","37","38","39","40","41","42","43","44","45","46","47","48","49","50","51","52","53","54","55","56","57","58","59"};
            menuMinuti = new JComboBox (minuti);
            p2.add(menuMinuti);
            //timezone
            String[] timeZone = {"-11","-10","-09","-08","-07","-06","-05","-04","-03","-02","-01","00","+01","+02","+03","+04","+05","+06","+07","+08","+09","+10","+11","+12"};
            menuTimeZone = new JComboBox (timeZone);
            p2.add(menuTimeZone);
            
            computeButton = new JButton("Compute");
            computeButton.setLayout(new FlowLayout());
            computeButton.addActionListener(new ActionListener()
            {
                public void actionPerformed(ActionEvent actionEvent)
                {
                	updateButton();
                }
            });
            p3 = new JPanel();
            p3.setLayout(new FlowLayout());
            p3.add(computeButton);                       
            
            
            JPanel widgetsPanel = new JPanel(new GridLayout(2, 2, 0, 0));
            widgetsPanel.add(new JLabel("Sun Coordinate:"));
            
            textLabel = (new JLabel("Lat: Long:")); 
            widgetsPanel.add(textLabel);      
            
            // Control panel assembly
            controlPanel.add(colorPanel);
            controlPanel.add(positionTypePanel);
            controlPanel.add(p1);
            controlPanel.add(p2);
            controlPanel.add(p3);
            controlPanel.add(widgetsPanel);
         
            return controlPanel;
        }
        
        private void updateButton()
        {
            new Thread(new Runnable() {
                public void run()
                {
                    compute();
                    updatePanels();
                    updateCal();
                }
            }, "LOS thread").start();
        }

        private void compute()
        {
            computeButton.setEnabled(false);
            computeButton.setText("Computing...");
            time = Calendar.getInstance();

            try
            {
            	int year = Integer.parseInt(anno.getText());
            	int month = Integer.parseInt((String)menuMesi.getSelectedItem()) - 1;
            	int day = Integer.parseInt((String)menuGiorni.getSelectedItem());
            	int hour = Integer.parseInt((String)menuOre.getSelectedItem()) + Integer.parseInt((String)menuTimeZone.getSelectedItem());
            	int minute = Integer.parseInt((String)menuMinuti.getSelectedItem());
            	time.clear();
            	time.set(year, month, day, hour, minute);
            	
            }
            finally
            {
                computeButton.setEnabled(true);
                computeButton.setText("Compute");
            }

        }

        // Update worldwind
        private void updateCal()
        {
            
            if (this.enableCheckBox.isSelected())
            {
                // Update colors
                this.tessellator.setLightColor(this.colorButton.getBackground());
                this.tessellator.setAmbientColor(this.ambientButton.getBackground());
                
                // Compute Sun direction
                Vec4 sun, light;              
                LatLon sunPos = AdvancedSunCalculator.subsolarPoint(time);
                sun = getWwd().getModel().getGlobe().computePointFromPosition(new Position(sunPos, 0)).normalize3();

                if (this.relativeRadioButton.isSelected())
                {
                	if (time!=null)
                	{                		
                		sunPos = AdvancedSunCalculator.subsolarPoint(time);
                        textLabel.setText("Lat:"+(Math.round(sunPos.latitude.degrees*1000.0)/1000.0)+" Long:"+
                        		(Math.round(sunPos.longitude.degrees*1000.0)/1000.0));
                        light = sun.getNegative3();
                        sun = getWwd().getModel().getGlobe().computePointFromPosition(new Position(sunPos, 0)).normalize3();
                        this.tessellator.setLightDirection(light);
                        this.tessellator.setAmbientColor(Color.WHITE);                    
                        this.atmosphereLayer.setSunDirection(sun); 
                	}
                }
                else
                {
                    sunPos = spp.getPosition();
                    // FP
                    textLabel.setText("Lat:"+(Math.round(sunPos.latitude.degrees*1000.0)/1000.0)+" Long:"+
                    		(Math.round(sunPos.longitude.degrees*1000.0)/1000.0));
                    sun = getWwd().getModel().getGlobe().computePointFromPosition(new Position(sunPos, 0)).normalize3();
                }
                light = sun.getNegative3();
                AppFrame.lensFlareLayer.setSunDirection(sun); 
                this.tessellator.setLightDirection(light);    
                this.tessellator.setAmbientColor(Color.WHITE);
                this.atmosphereLayer.setSunDirection(sun);                 
            }
            else
            {
                // Disable UI controls
                // Turn off lighting
                this.tessellator.setLightDirection(null);
                AppFrame.lensFlareLayer.setSunDirection(null);
                this.atmosphereLayer.setSunDirection(null);
            }
            // Redraw
            this.getWwd().redraw();
        }
        

        public static ListObject getlistOfBuilding()
        {
        	return listOfBuilding;
        }
        
        public static ListPosition getlistOfPosition()
        {
        	return listOfPosition;
        }
        
        public static Vec4 getSunPosition()
        {
        	return lensFlareLayer.getSunPoint();
        }  
        
        public static HighResolutionTerrain getHighResolutionTerrain()
        {
        	return terrain;
        }  

        public static Globe getGlobe()
        {
        	return globe;
        }
        
        public static WorldWindow getWWW()
        {
        	return wwd;
        }
        
        public static Vec4 getSunDirection()
        {
        	return lensFlareLayer.getSunDirection();
        }
        
        // Update PANELS
        private void updatePanels()
        {
            // FP
            
            if (this.enableCheckBox.isSelected())
            {
                // Enable UI controls
                this.colorButton.setEnabled(true);
                this.ambientButton.setEnabled(true);
                this.absoluteRadioButton.setEnabled(true);
                this.relativeRadioButton.setEnabled(true);
                // Update colors
                this.tessellator.setLightColor(this.colorButton.getBackground());
                this.tessellator.setAmbientColor(this.ambientButton.getBackground());
                

                if (this.relativeRadioButton.isSelected())
                {
                    // Enable UI controls
                	this.menuGiorni.setEnabled(true);
                	this.menuMesi.setEnabled(true);
                	this.anno.setEnabled(true);
                	this.menuOre.setEnabled(true);
                	this.menuMinuti.setEnabled(true);
                	this.menuTimeZone.setEnabled(true);
                	this.computeButton.setEnabled(true);                	
                }
                else
                {                	
                	this.menuGiorni.setEnabled(false);
                	this.menuMesi.setEnabled(false);
                	this.anno.setEnabled(false);
                	this.menuOre.setEnabled(false);
                	this.menuMinuti.setEnabled(false);
                	this.menuTimeZone.setEnabled(false);
                	this.computeButton.setEnabled(false);
                }
            }
            else
            {
                // Disable UI controls
                this.colorButton.setEnabled(false);
                this.ambientButton.setEnabled(false);
                this.absoluteRadioButton.setEnabled(false);
                this.relativeRadioButton.setEnabled(false);
            }
        } 
        
    }


    public static void main(String[] args)
    {

        Configuration.setValue(AVKey.TESSELLATOR_CLASS_NAME, RectangularNormalTessellator.class.getName());
        Configuration.setValue(AVKey.TESSELLATOR_CLASS_NAME, RectangularNormalTessellator.class.getName());
		Configuration.setValue(AVKey.INITIAL_LATITUDE, 43.4386);
		Configuration.setValue(AVKey.INITIAL_LONGITUDE, 11.7786);
		Configuration.setValue(AVKey.INITIAL_ALTITUDE, 25e5);
        ApplicationTemplate.start("World Wind Sun Shading", AppFrame.class);

    }
}
