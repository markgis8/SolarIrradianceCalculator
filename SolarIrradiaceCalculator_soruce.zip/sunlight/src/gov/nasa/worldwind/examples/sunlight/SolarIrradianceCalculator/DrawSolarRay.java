package gov.nasa.worldwind.examples.sunlight.SolarIrradianceCalculator;

import gov.nasa.worldwind.WorldWind;
import gov.nasa.worldwind.WorldWindow;
import gov.nasa.worldwind.geom.Position;
import gov.nasa.worldwind.globes.Globe;
import gov.nasa.worldwind.layers.RenderableLayer;
import gov.nasa.worldwind.render.BasicShapeAttributes;
import gov.nasa.worldwind.render.Material;
import gov.nasa.worldwind.render.Path;
import gov.nasa.worldwind.render.ShapeAttributes;

/**
 * Copyright (C) 2001 United States Government
 * as represented by the Administrator of the
 * National Aeronautics and Space Administration.
 * All Rights Reserved.
 * @author  Marco Piragnolo
 * Cirgeo, University of Padua, francesco.pirotti@unipd.it, marco.piragnolo@unipd.it
 * @version 0.1  2014-29-05 11:46
 */

public class DrawSolarRay {
	/**Draw a path from a  point to the sun*/
	private Globe globe;     
	private WorldWindow wwd;
	
	public Path drawSolarRay(Position center)	
	{   /**create a path for solar ray*/      
        ShapeAttributes pathAttributes = new BasicShapeAttributes();
        pathAttributes.setOutlineMaterial(Material.GREEN);   
        pathAttributes.setInteriorMaterial(Material.BLUE);
        pathAttributes.setOutlineWidth(1);  
     
		Position pos = SunShading.AppFrame.getGlobe().computePositionFromPoint(SunShading.AppFrame.getSunPosition()); //calcola la posizione del sole da coordinate cartesiane a latotudine longitudine

		Position pA= new Position(pos.getLatitude(), pos.getLongitude(), pos.getElevation());//punto iniziale
        Position pB=new Position(center.getLatitude(), center.getLongitude(), center.getElevation());//punto finale
        
        Path path2 = new Path(pB, pA );//draw a path from a  point to the sun
        path2.setAltitudeMode(WorldWind.RELATIVE_TO_GROUND);
        pathAttributes.setOutlineMaterial(Material.YELLOW);   
        pathAttributes.setInteriorMaterial(Material.YELLOW);
        pathAttributes.setOutlineWidth(1);     
        path2.setAttributes(pathAttributes);
        path2.setVisible(true);
        return path2;
	}
	
	public void insertSolarRayLayer(WorldWindow wwd)
	{	/**insert the layer*/
		this.wwd=wwd;
		RenderableLayer sole= new RenderableLayer();			
		sole.setName("SolarRay");
		sole.setEnabled(false);
		this.wwd.getModel().getLayers().add(sole);
	}
	
	public void insertSolarRay(Path path)
	{	/**insert a raylight in the solar layer*/
		RenderableLayer layer=(RenderableLayer) wwd.getModel().getLayers().getLayerByName("SolarRay");
		layer.addRenderable(path);		
	}
}
