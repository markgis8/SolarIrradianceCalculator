package gov.nasa.worldwind.examples.sunlight.SolarIrradianceCalculator;

/**
 * Copyright (C) 2001 United States Government
 * as represented by the Administrator of the
 * National Aeronautics and Space Administration.
 * All Rights Reserved.
 * @author  Marco Piragnolo
 * Cirgeo, University of Padua, francesco.pirotti@unipd.it, marco.piragnolo@unipd.it
 * Algorithm based on Gianni Comini e Stefano Savino http://books.google.it/books?id=lPszfpUCpdQC&printsec=frontcover&hl=it&source=gbs_ge_summary_r&cad=0#v=onepage&q&f=false
 * http://www.shodor.org/os411/courses/_master/tools/calculators/solarrad/
 * @version 0.1  2014-29-05 11:46
 */

public class Irradiance {
	/**Estimate total irradiance (direct,  diffusive, reflected) */
	double g=1360.8; // W/m2
	double n;
	double w;
	double inc;
	double h;
	double slope;
	double rho;
	double cloud;
	
	public double totIrradiance(double incidence, double slope, double hourAngle, double rho, int cloud, double day, double h, double sunElevation)
	{
		/**Estimate total irradiance (direct,  diffusive, reflected) */
		this.inc=Math.toRadians(incidence);
		this.slope=Math.toRadians(slope);
		this.w=Math.toRadians(hourAngle);
		this.rho=rho;
		this.cloud=cloud;
		this.n=day;
		this.h=h/1000;
		double ir=0;
		
		double g1=g*(1+0.033*Math.cos(Math.toRadians(360*this.n/365)));
		double gg=g1*(1-0.75*Math.pow(this.cloud/100, 3.4));//cloud coverage
		
		double g0h=gg*Math.cos(this.inc);
		double z=this.inc+this.slope;

		if(this.h>2.5){this.h=2.5;}
		double a0= 0.424-0.0082*Math.pow((6-this.h), 2); 
		double a1= 0.5055+0.0060*Math.pow((6.5-this.h), 2);
		double a2= 0.271+0.019*Math.pow((2.5-this.h), 2);
	
		double tf= a0+a1*Math.exp(-(a2/Math.cos(z)));

		if(tf>3){
			   	tf= a0+a1*Math.exp( -(a2/Math.sin(Math.toRadians(sunElevation))));
		 		}
		
		double Cdir= g0h*tf;//direct	
				
		double td=0.271-0.16*tf;
		double Gdh= td*g0h; //diffuse component of ideal horizontal
		double fih= (1+Math.cos(this.slope))/2;  //diffuse component of visible sky
		double Cdiff= Gdh*fih;//tot diffusive
		
		if(slope>0){
		double grs= this.rho * (Cdiff+Cdir); //coefficient for material
		double fis=(1-Math.cos(this.slope))/2; // view factor of the ground
		double Crif= grs*fis;
		ir=Cdir+Cdiff+Crif;}
		else if(slope==0){ir=Cdir+Cdiff; }
		if(ir<0){ir=0;} else if (ir>1360.8){ir=0;}		
		return ir; 
	}
	
	public double directIrradiance(double incidence, double slope, double hourAngle, double rho, double cloud, double day, double h, double sunElevation)
	{
		/**Estimate direct irradiance */
		this.inc=Math.toRadians(incidence);
		this.slope=Math.toRadians(slope);
		this.w=Math.toRadians(hourAngle);
		this.rho=rho;
		this.n=day;
		this.h=h/1000;
			
		double g1=g*(1+0.033*Math.cos(Math.toRadians(360*this.n/365)));
		double gg=g1*(1-0.75*Math.pow(this.cloud/100, 3.4));//cloud coverage
		double g0h=gg*Math.cos(this.inc)*3.6*24/60; 	
		
		double z=this.inc+this.slope;

		if(this.h>2.5){this.h=2.4;}
		double a0= 0.424-0.0082*Math.pow((6-this.h), 2); 
		double a1= 0.5055+0.0060*Math.pow((6.5-this.h), 2);
		double a2= 0.271+0.019*Math.pow((2.5-this.h), 2);

		double tf= a0+a1*Math.exp(-(a2/Math.cos(z)));
		
		if(tf>3){
			   	tf= a0+a1*Math.exp( -(a2/Math.sin(Math.toRadians(sunElevation))));			   
		 		}

		double Cdir= g0h*tf;//direct
	
		return Cdir;
	}
	
	public double diffusivIrradiance(double incidence, double slope, double hourAngle, double rho, double cloud, double day, double h, double sunElevation)
	{
		/**Estimate diffusive irradiance */
		this.inc=Math.toRadians(incidence);
		this.slope=Math.toRadians(slope);
		this.w=Math.toRadians(hourAngle);
		this.rho=rho;
		this.n=day;
		this.h=h/1000;		
	
		double g1=g*(1+0.033*Math.cos(Math.toRadians(360*this.n/365)));
		double gg=g1*(1-0.75*Math.pow(this.cloud/100, 3.4));//cloud coverage
		double g0h=gg*Math.cos(this.inc)*3.6*24/60; 
		
		double z=this.inc+this.slope;

		if(this.h>2.5){this.h=2.5;}
		double a0= 0.424-0.0082*Math.pow((6-this.h), 2); 
		double a1= 0.5055+0.0060*Math.pow((6.5-this.h), 2);
		double a2= 0.271+0.019*Math.pow((2.5-this.h), 2);

		double tf= a0+a1*Math.exp(-(a2/Math.cos(z)));
		if(tf>3){
			   	tf= a0+a1*Math.exp( -(a2/Math.sin(Math.toRadians(sunElevation))));			   	
		 		}

		double td=0.271-0.16*tf;
		double Gdh= td*g0h; 
		double fih= (1+Math.cos(this.slope))/2;  
		double Cdiff= Gdh*fih;

		return Cdiff;
	}
	
	public double refletctedIrradiance(double incidence, double slope, double hourAngle, double rho, double cloud ,double day, double h, double sunElevation)
	{
		/** estimate reflected irradiance*/
		this.inc=Math.toRadians(incidence);
		this.slope=Math.toRadians(slope);
		this.w=Math.toRadians(hourAngle);
		this.rho=rho;
		this.n=day;
		this.h=h/1000;		
		double Crif=0;
		
		if (slope==0){return Crif;}
		else{		
			double g1=g*(1+0.033*Math.cos(Math.toRadians(360*this.n/365)));
			double gg=g1*(1-0.75*Math.pow(this.cloud/100, 3.4));//cloud coverage
			double g0h=gg*Math.cos(this.inc)*3.6*24/60; 	
			
			double z=this.inc+this.slope;
	
			if(this.h>2.5){this.h=2.5;}
			double a0= 0.424-0.0082*Math.pow((6-this.h), 2); 
			double a1= 0.5055+0.0060*Math.pow((6.5-this.h), 2);
			double a2= 0.271+0.019*Math.pow((2.5-this.h), 2);
	
			double tf= a0+a1*Math.exp(-(a2/Math.cos(z)));
			if(tf>3){
				   	tf= a0+a1*Math.exp( -(a2/Math.sin(Math.toRadians(sunElevation))));
			 		}
	
			double Cdir= g0h*tf;
					
			double td=0.271-0.16*tf;
			double Gdh= td*g0h; 
			double fih= (1+Math.cos(this.slope))/2;  
			double Cdiff= Gdh*fih;
			
			if(slope>0){
			double grs= this.rho * (Cdiff+Cdir); 
			double fis=(1-Math.cos(this.slope))/2; 
			Crif= grs*fis;}
			return Crif;
		}		
	}

}
