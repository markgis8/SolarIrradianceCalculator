package gov.nasa.worldwind.examples.sunlight.SolarIrradianceCalculator;

/**
 * Copyright (C) 2001 United States Government
 * as represented by the Administrator of the
 * National Aeronautics and Space Administration.
 * All Rights Reserved.
 * @author  Marco Piragnolo
 * Cirgeo, University of Padua, francesco.pirotti@unipd.it, marco.piragnolo@unipd.it
 * @version 0.1  2014-29-05 11:46
 */
import java.util.TreeMap;



public class ListPosition {
	/** this is a hashmap of buildings */
	private TreeMap<Integer, Object> treePosition;
		
		public ListPosition()
		{	/** create hashmap of buildings */		
			TreeMap<Integer, Object> positionInfo = new TreeMap<Integer, Object>();
			this.treePosition=positionInfo;
		}	
		
        
		public void insertTerrainHash(int index, Object obj)
        {   /** insert point in the hashmap */          	
        	treePosition.put(index, obj);
        }
		
		public void clearTerrainHash()
        {               	
        	treePosition.clear();
        }
        
        protected TreeMap<Integer,  Object> getTerrainHash()
        {	/** get hashmap of buildings */
        	return treePosition;      	
        } 
}

