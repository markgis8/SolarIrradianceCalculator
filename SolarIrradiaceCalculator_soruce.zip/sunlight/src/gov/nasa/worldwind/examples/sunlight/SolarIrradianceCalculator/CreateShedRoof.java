package gov.nasa.worldwind.examples.sunlight.SolarIrradianceCalculator;

import gov.nasa.worldwind.WorldWindow;
import gov.nasa.worldwind.geom.Angle;
import gov.nasa.worldwind.geom.Position;
import gov.nasa.worldwind.globes.Globe;
import gov.nasa.worldwind.render.BasicShapeAttributes;
import gov.nasa.worldwind.render.DrawContext;
import gov.nasa.worldwind.render.ExtrudedPolygon;
import gov.nasa.worldwind.render.Material;
import gov.nasa.worldwind.render.ShapeAttributes;
import gov.nasa.worldwindx.examples.LayerPanel;

/**
 * Copyright (C) 2001 United States Government
 * as represented by the Administrator of the
 * National Aeronautics and Space Administration.
 * All Rights Reserved.
 * @author  Marco Piragnolo
 * Cirgeo, University of Padua, francesco.pirotti@unipd.it, marco.piragnolo@unipd.it
 * @version 0.1  2014-29-05 11:46
 */

import java.awt.Color;
import java.util.ArrayList;

public class CreateShedRoof extends Building{
	/** This class create an extruded polygon with a shed roof. Gable roof is made by one sheet.* */
	public CreateShedRoof(double lat, double lon, double lenght, double width, double height, double slope, int aspect, int aspectSide, Globe globe, WorldWindow wwd, LayerPanel layerPanel, DrawContext dc)  
	{
		super(lat, lon, lenght, width, height, slope, aspect, aspectSide, globe, wwd, layerPanel, dc);
		
		 ShapeAttributes sideAttributes = new BasicShapeAttributes();
            sideAttributes.setInteriorMaterial(new Material(new Color(215, 255, 223)));           
            sideAttributes.setOutlineOpacity(1);
            sideAttributes.setInteriorOpacity(1);
            sideAttributes.setOutlineMaterial(Material.BLACK);
            sideAttributes.setOutlineWidth(2);
            sideAttributes.setDrawOutline(true);
            sideAttributes.setDrawInterior(true);
            sideAttributes.setEnableLighting(true);

            ShapeAttributes capAttributes = new BasicShapeAttributes(sideAttributes);
            capAttributes.setInteriorMaterial(Material.ORANGE);           
            capAttributes.setInteriorOpacity(1); 
			
            ArrayList<Position> positions1cal = new ArrayList<Position>(); 
            MeterToAngle meta =new MeterToAngle();         
            Position baseA = new Position(Position.fromDegrees(lat, lon), height);                       
            Position posizB= new Position(baseA.getLatitude(), baseA.getLongitude().add(meta.lonMetersAngle(lenght, lat, lon,  globe, dc)), height);         
            Position posizC= new Position(baseA.getLatitude().add(meta.latMetersAngle(width, lat, lon,  globe, dc)), baseA.getLongitude().add(meta.lonMetersAngle(lenght, lat, lon,  globe, dc)), height);           
            Position posizD= new Position(baseA.getLatitude().add(meta.latMetersAngle(width, lat, lon,  globe, dc)), baseA.getLongitude(), height);         
            
            positions1cal.add(baseA); 
            positions1cal.add(posizB);
            positions1cal.add(posizC);
            positions1cal.add(posizD);
            
            //convert double in angle
	        Angle slopeA=Angle.fromDegrees(slope);
	        
	        //calculus the roof height from roof slope
	        double roofheight=width*slopeA.multiply(2).tanHalfAngle();	 	       
	        
	        switch(aspect)
	        { 
	        	case 180:   //nord   
	        		baseA=baseA.add(Position.fromDegrees(0,0,roofheight));
	        		posizB=posizB.add(Position.fromDegrees(0,0,roofheight));
	        		positions1cal.set(0, baseA);
	        		positions1cal.set(1, posizB);
	                //compute normal to roof	        		
	                computeNormalBuilding(positions1cal.get(0), positions1cal.get(1), positions1cal.get(2), getBaricenter(positions1cal));
	            break;
	        	case 90:  //east
	        		baseA=baseA.add(Position.fromDegrees(0,0,roofheight));
	        		posizD=posizD.add(Position.fromDegrees(0,0,roofheight));
	        		positions1cal.set(0, baseA);
	        		positions1cal.set(3, posizD);
	                //compute normal to roof
	        		computeNormalBuilding(positions1cal.get(0), positions1cal.get(1), positions1cal.get(2), getBaricenter(positions1cal));
	        	break;
	        	case 0: //sud
	        		posizC=posizC.add(Position.fromDegrees(0,0,roofheight));
			        posizD=posizD.add(Position.fromDegrees(0,0,roofheight));
	        		positions1cal.set(2, posizC);
	        		positions1cal.set(3, posizD);
	                //compute normal to roof
	        		computeNormalBuilding(positions1cal.get(0), positions1cal.get(1), positions1cal.get(2), getBaricenter(positions1cal));
		        break;
	        	case 270: //west
	        		posizB=posizB.add(Position.fromDegrees(0,0,roofheight));
	        		posizC=posizC.add(Position.fromDegrees(0,0,roofheight));
	        		positions1cal.set(1, posizB);
	        		positions1cal.set(2, posizC);
	                //compute normal to roof
	        		computeNormalBuilding(positions1cal.get(0), positions1cal.get(1), positions1cal.get(2), getBaricenter(positions1cal));
		        break;
	        }           

            ExtrudedPolygon   poly1cal = new ExtrudedPolygon (positions1cal);
            poly1cal.setSideAttributes(sideAttributes);         
            poly1cal.setCapAttributes(capAttributes);            
            float[] texCoords = null;
            if(aspect==90 || aspect== 270)    {texCoords=new float[]{0, 0, 0, 1, 1, 1, 1, 0};}
            else if (aspect==0 || aspect== 180){texCoords=new float[]{0, 0, 1, 0, 1, 1, 0, 1};}
            
            poly1cal.setCapImageSource("images/roof37.jpg", texCoords, 4);
            poly1cal.setAltitudeMode(2);  	  
            setPolygon(poly1cal);
	}
}	
