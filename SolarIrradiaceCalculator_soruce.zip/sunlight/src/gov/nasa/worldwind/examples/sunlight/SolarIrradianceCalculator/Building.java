/*
Copyright (C) 2001, 2009 United States Government
as represented by the Administrator of the
National Aeronautics and Space Administration.
All Rights Reserved.
*/

package gov.nasa.worldwind.examples.sunlight.SolarIrradianceCalculator;

import gov.nasa.worldwind.WorldWind;
import gov.nasa.worldwind.WorldWindow;
import gov.nasa.worldwind.examples.sunlight.SolarIrradianceCalculator.SunShading.AppFrame;
import gov.nasa.worldwind.geom.*;
import gov.nasa.worldwind.globes.Globe;
import gov.nasa.worldwind.layers.RenderableLayer;
import gov.nasa.worldwind.render.*;
import gov.nasa.worldwind.util.BasicDragger;
import gov.nasa.worldwindx.examples.LayerPanel;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 * Copyright (C) 2001 United States Government
 * as represented by the Administrator of the
 * National Aeronautics and Space Administration.
 * All Rights Reserved.
 * @author  Marco Piragnolo
 * Cirgeo, University of Padua, francesco.pirotti@unipd.it, marco.piragnolo@unipd.it
 * @version 0.1  2014-29-05 11:46
 */

/**
 * Shows how to use {@link ExtrudedPolygon}.
 *
 * @author tag
 * @version $Id: ExtrudedPolygons.java 1 2011-07-16 23:22:47Z dcollins $
 */
public class Building extends ExtrudedPolygon
{ 	
		private DrawContext dc;
    	private WorldWindow wwd;
    	protected LayerPanel layerPanel;
    	private Globe globe;          	
    	static String incidence_print;
    	private int id;
    	private String name;
    	private double lenght;
    	private double width;
    	private double height;
    	private double slope;
    	protected int aspect;
    	protected int aspectSide;
    	private double lat;
    	private double lon;
    	private double incidence;
    	private double elevationForIncidenceCalc;
    	private ExtrudedPolygon polygon;
    	ArrayList<Position> positions;
    	protected ArrayList<Position> positions2n = new ArrayList<Position>();
    	protected ArrayList<Position> positions2s = new ArrayList<Position>();
    	protected ArrayList<Position> positions2e = new ArrayList<Position>();
    	protected ArrayList<Position> positions2w = new ArrayList<Position>();
    	protected ArrayList<Position> positions4n = new ArrayList<Position>();
    	protected ArrayList<Position> positions4s = new ArrayList<Position>();
    	protected ArrayList<Position> positions4e = new ArrayList<Position>();
    	protected ArrayList<Position> positions4w = new ArrayList<Position>();
    	private Position start; 
    	private Position endPos; 
    	private Path  path;
    	private RenderableLayer buildinglayer = new RenderableLayer();
    	private RenderableLayer normalLayer = new RenderableLayer();
    	private static Integer buildingIndex=0;


		public Building(double lat, double lon, double lenght, double width, double height, double slope, int aspect, int aspectSide, Globe globe, WorldWindow wwd, LayerPanel layerPanel, DrawContext dc)
        { 	/** Building general object */
            
            this.wwd=wwd;
			this.globe= globe;
            this.layerPanel=layerPanel;   
            this.lenght=lenght;
            this.width=width;
            this.height=height;
            this.slope=slope;
            this.aspect=aspect; //aspect of building
            this.aspectSide=aspectSide; //aspect of roof
            this.lat=lat;
            this.lon=lon;               
        }				
		
		private void setId(int id)
		{ 	/**set id of building*/
			this.id=id;
		}
		
		public void setName(String name)
		{	/**set name of building*/
			this.name=name;
		}
	
		protected void setAspect(int aspect)
		{	/**set aspect of building*/
			this.aspect=aspect;
		}
		
		protected  void setSlope(double slope)
		{	/**set slope of roof'sbuilding*/
			this.slope=slope;
		}		
		
		protected  void setIncidence(double incidence)
		{	/**set the incidence of roof's building*/
			this.incidence=incidence;
		}
		
		protected void setPolygon(ExtrudedPolygon polygon)
		{	/**set polygon*/
			this.polygon=polygon;
		}
		
		public int getId()
		{	/** return building's id*/
			return this.id;
		}
		
		public String getName()
		{	/** return building's name*/
			return this.name;
		}
		
		public double getLenght()
		{	/** return building's lenght*/
			return this.lenght;
		}
		
		public double getWidth()
		{	/** return building's width*/
			return this.width;
		}
		
		public double getHeight()
		{	/** return building's height*/
			return this.height;
		}
		
		public int getAspectSide()
		{	/** return the aspect of the roof*/		
			return this.aspectSide;
		}
		
		public double getSlope()
		{	/** return the slope of the roof*/	
			return slope;
		}					
		
		public double getincidence()
		{ 	/** return the incidence of the roof*/	
			return incidence;
		}
		
		public ExtrudedPolygon getPolygon()
		{	/** return extruded polygon*/	
			return polygon;
		}	
		
		public ArrayList<ExtrudedPolygon> getBuildingList()
		{	/** return the building list*/
			return this.getBuildingList();
		}
		
		
		
		protected void inserBuildingtLayer()
		{	/** create layer that contains the building*/
			wwd.addSelectListener(new BasicDragger(wwd));
	        //add layers
	        buildinglayer.isEnabled();
	        buildinglayer.setPickEnabled(true);  
	        buildinglayer.setName("Building");
	        SunShading.insertBeforeCompass(this.wwd, buildinglayer);
	        this.layerPanel.update(this.wwd);
	    }
		
		
		protected void inserNormalRoofLayer()
		{   /** create layer that contains the normal to roof*/       
			wwd.addSelectListener(new BasicDragger(wwd));
	        //add layers
			normalLayer.isEnabled();
			normalLayer.setPickEnabled(true);  
			normalLayer.setName("Normal to Roof");
	        SunShading.insertBeforeCompass(this.wwd, normalLayer);
	        this.layerPanel.update(this.wwd);
	    }
		
		
		protected void insertBuilding(ExtrudedPolygon polygon4)
		{	/** insert building into the building's layer*/				
			RenderableLayer layer=(RenderableLayer) wwd.getModel().getLayers().getLayerByName("Building");
			layer.addRenderable(polygon4);        	      	
			wwd.getModel().getLayers().remove("Building");
            this.layerPanel.update(this.wwd);          
		}			
	
		
		protected void insertNormalToRoof()
		{	/** insert normal ray into normal's layer*/				
			RenderableLayer normalLayer=(RenderableLayer) wwd.getModel().getLayers().getLayerByName("Normal to Roof");
			normalLayer.addRenderable(path);
			 wwd.getModel().getLayers().remove("Normal to Roof");
			this.layerPanel.update(this.wwd);
		}
		
		/** insert building into hash*/
		protected void insertBuildingHash(Building building)
		{	
			AppFrame.getlistOfBuilding().insertBuildingHash(buildingIndex, building);	
			setId(buildingIndex);
			setName("bldg"+buildingIndex);
	    	buildingIndex++;
		}
		
		/**Using 3 points it computes the plane of the roof; then it calculates the normal to the plane and put the layer into Nasa World Wind panel*/
		public void computeNormalBuilding(Position v1, Position v2, Position v3, Position center)	
		{             
            //Compute point of the plan
            Vec4 p1 = this.wwd.getModel().getGlobe().computePointFromPosition(v1);
            Vec4 p2 = this.wwd.getModel().getGlobe().computePointFromPosition(v2);
            Vec4 p3 = this.wwd.getModel().getGlobe().computePointFromPosition(v3);
            
            // Compute vector normal to surface of the roof using three point 
            Vec4 roofNormal = p1.subtract3(p3).cross3(
                    p1.subtract3(p2));

            // Transfrom the vector in a line. The line hasn't yet origin in the barycenter       
            Line roofNormalH=new Line(this.wwd.getModel().getGlobe().computePointFromPosition(center), roofNormal);
            
            // Compute the start elevation position of the line                  
            this.elevationForIncidenceCalc = this.wwd.getModel().getGlobe().computePositionFromPoint(roofNormalH.getOrigin()).getElevation();       
            
            computeIncidenceBuilding(center);
            
            // Compute the start position from barycenter coordinates at correct elevation
            Position start= new Position(center.getLatitude(), center.getLongitude(), center.getElevation());  
            this.start=start;
           
            // Compute the end point position of the line
            Position endPos=this.wwd.getModel().getGlobe().computePositionFromPoint(roofNormalH.getPointAt(-100));                                                       
            this.endPos=endPos;       
           
            Path  path = new Path(this.start, this.endPos);
            path.setVisible(true);
            path.setAltitudeMode(WorldWind.RELATIVE_TO_GROUND);       
            ShapeAttributes pathAttributes = new BasicShapeAttributes();
            pathAttributes.setOutlineMaterial(Material.GREEN);   
            pathAttributes.setInteriorMaterial(Material.BLUE);
            pathAttributes.setOutlineWidth(1);  
            path.setAttributes(pathAttributes);
            this.path=path;                           		
		}
		 
		public double computeIncidenceBuilding(Position center)	
		{   /**Calculate the angle of incidence*/       
			BasicSunPositionProvider bspp = new BasicSunPositionProvider();                  
	        double incidence=AdvancedSunCalculator.subsolarIncidence(bspp.getCalendar(), center, this.elevationForIncidenceCalc, (double) this.aspectSide, this.getSlope());	   
	        this.incidence=incidence;
	        return incidence;
		}	
		
		
		
		protected void calculateHippedRoof()  
		{	/**Calculate the position for a Hipped Roof and put them into arrays*/ 	      
            Position baseA = new Position(Position.fromDegrees(lat, lon), height);//a                    
            MeterToAngle meta =new MeterToAngle();
            Position posizAB= new Position(
            		baseA.getLatitude(), 
            		(baseA.getLongitude().add( 
            				baseA.getLongitude().add(meta.lonMetersAngle(lenght, lat, lon,  globe, dc))
            				).divide(2)), height);//ab
            
            Position posizB= new Position(baseA.getLatitude(), baseA.getLongitude().add(meta.lonMetersAngle(lenght, lat, lon,  globe, dc)), height);//b      
            
            Position posizBC= new Position(
            		(baseA.getLatitude().add(baseA.getLatitude().add(meta.latMetersAngle(width, lat, lon,  globe, dc)))).divide(2), 
            		baseA.getLongitude().add(meta.lonMetersAngle(lenght, lat, lon,  globe, dc)), 
            		height);//c
            
            Position posizC= new Position(baseA.getLatitude().add(meta.latMetersAngle(width, lat, lon,  globe, dc)), baseA.getLongitude().add(meta.lonMetersAngle(lenght, lat, lon,  globe, dc)), height);//c                                                        
            
            Position posizCD= new Position(
            		baseA.getLatitude().add(meta.latMetersAngle(width, lat, lon,  globe, dc)), 
            		(baseA.getLongitude().add(
            				baseA.getLongitude().add(meta.lonMetersAngle(lenght, lat, lon,  globe, dc))
            				).divide(2)), height);//cd
            
            Position posizD= new Position(baseA.getLatitude().add(meta.latMetersAngle(width, lat, lon,  globe, dc)), baseA.getLongitude(), height);//d
            
            Position posizAD= new Position(
            		(baseA.getLatitude().add(baseA.getLatitude().add(meta.latMetersAngle(width, lat, lon,  globe, dc)))).divide(2), 
            				baseA.getLongitude(), 
            				height);            
            
            //roof nord c d dc/2                            
            positions4n.add(posizC);            	
            positions4n.add(posizD);
            	positions4n.add(posizCD);
        	positions4n.add(posizAD);
        	positions4n.add(posizBC);

        	
            //roof sud a b ab/2
            positions4s.add(posizB); // b  
            positions4s.add(baseA); // a                                 
        		positions4s.add(posizAB); //  ab/2
        	positions4s.add(posizAD);
        	positions4s.add(posizBC);	        
  
        	 
            //roof est b ab/2 dc/2 c
            positions4e.add(posizB); //  b  
            	positions4e.add(posizAB); //  ab/2
            	positions4e.add(posizCD); //  dc/2 
        	positions4e.add(posizC); // c 
        	positions4e.add(posizBC); // bc 
 
        	
            // roof ovest a ab/2 dc/2 d
            positions4w.add(baseA); // a  
            	positions4w.add(posizAB); //  ab/2
            	positions4w.add(posizCD); //  dc/2
        	positions4w.add(posizD); // d  
        	positions4w.add(posizAD); //a d 
  
        	 
            //convert double in angle
	        Angle slopeA=Angle.fromDegrees(slope);
	        
	        //calculus the roof height from roof slope
	        double roofheight=width/2*slopeA.multiply(2).tanHalfAngle();
	        
	        //calculus the side base to have the correct roof slope
	        double sidebase=roofheight*slopeA.multiply(2).tanHalfAngle();                  
	        
	        switch(aspect)
	        { 
	        	case 180:   //north  
	        	case 0: //south	

	                posizAD= new Position(
	                		(baseA.getLatitude().add(baseA.getLatitude().add(meta.latMetersAngle(width, lat, lon,  globe, dc)))).divide(2), 
	                				baseA.getLongitude().add(meta.lonMetersAngle(sidebase, lat, lon,  globe, dc)), 
	                				height+roofheight);
	        		
	                if( (posizAD.getLongitude().degrees>posizAB.getLongitude().degrees) ){JOptionPane.showMessageDialog(null, "Lon AD Error roof slope is too high");break;} 
	                else{             
		                posizBC= new Position(
		                		(baseA.getLatitude().add(baseA.getLatitude().add(meta.latMetersAngle(width, lat, lon,  globe, dc)))).divide(2), 
		                		 baseA.getLongitude().add(meta.lonMetersAngle(lenght, lat, lon,  globe, dc)).subtract(meta.lonMetersAngle(sidebase, lat, lon,  globe, dc)), 
		                		 height+roofheight);//c
		        		
		                positions4n.set(3, posizAD);
		                positions4n.set(4, posizBC);
		                positions4n.remove(2);	                
		                
		                positions4s.set(3, posizAD);
		                positions4s.set(4, posizBC);
		                positions4s.remove(2);
		                
		                positions4e.set(4, posizBC);
		                positions4e.remove(2);
		                positions4e.remove(1);
		                
		                positions4w.set(4, posizAD);
		                positions4w.remove(2);
		                positions4w.remove(1);
		                
		                posizAB= new Position(
		                		baseA.getLatitude().add(meta.latMetersAngle(sidebase, lat, lon,  globe, dc)), 
		                		(baseA.getLongitude().add( 
		                				baseA.getLongitude().add(meta.lonMetersAngle(lenght, lat, lon,  globe, dc))
		                				).divide(2)), height+roofheight);//ab		                
	                }	                
			    break;
			    
	        	case 90:  //east
	        	case 270: //west  	        		
	        		posizCD= new Position(
	                		baseA.getLatitude().add(meta.latMetersAngle(width, lat, lon,  globe, dc)).subtract((meta.latMetersAngle(sidebase, lat, lon,  globe, dc))), 
	                		(baseA.getLongitude().add(
	                				baseA.getLongitude().add(meta.lonMetersAngle(lenght, lat, lon,  globe, dc))
	                				).divide(2)), height+roofheight);//cd
	               
	        		if( (posizCD.getLatitude().degrees<posizBC.getLatitude().degrees) ){JOptionPane.showMessageDialog(null, "Lat CD Error roof slope is too high");break;}
	        		else{
		        		posizAB= new Position(
		                		baseA.getLatitude().add(meta.latMetersAngle(sidebase, lat, lon,  globe, dc)), 
		                		(baseA.getLongitude().add( 
		                				baseA.getLongitude().add(meta.lonMetersAngle(lenght, lat, lon,  globe, dc))
		                				).divide(2)), height+roofheight);//ab
	
		        		positions4n.set(2,posizCD);
		        		positions4n.remove(4);
		        		positions4n.remove(3);		               
		                
		        		positions4s.set(2,posizAB);
		        		positions4s.remove(4);
		        		positions4s.remove(3);		        		
		        		
		        		positions4e.set(1, posizAB); 
		                positions4e.set(2, posizCD);	                
		                positions4e.remove(4);		                
		                
		                positions4w.set(1, posizAB); 
		                positions4w.set(2, posizCD); 
		                positions4w.remove(4);		                
	        		}
	        	break;		        	
	        }	        			
       }	
		
		protected void calculateGable()
		{
			ArrayList<Position> positions1cal = new ArrayList<Position>(); 
            MeterToAngle meta =new MeterToAngle();           
            Position baseA = new Position(Position.fromDegrees(lat, lon), height);//a                  
                                
            Position posizAB= new Position(
            		baseA.getLatitude(), 
            		(baseA.getLongitude().add( 
            				baseA.getLongitude().add(meta.lonMetersAngle(lenght, lat, lon,  globe, dc))
            				).divide(2)), height);//ab
            
            Position posizB= new Position(baseA.getLatitude(), baseA.getLongitude().add(meta.lonMetersAngle(lenght, lat, lon,  globe, dc)), height);//b                  
            
            Position posizBC= new Position(
            		(baseA.getLatitude().add(baseA.getLatitude().add(meta.latMetersAngle(width, lat, lon,  globe, dc)))).divide(2), 
            		baseA.getLongitude().add(meta.lonMetersAngle(lenght, lat, lon,  globe, dc)), 
            		height);//c
            
            Position posizC= new Position(baseA.getLatitude().add(meta.latMetersAngle(width, lat, lon,  globe, dc)), baseA.getLongitude().add(meta.lonMetersAngle(lenght, lat, lon,  globe, dc)), height);//c                                                        
            
            Position posizCD= new Position(
            		baseA.getLatitude().add(meta.latMetersAngle(width, lat, lon,  globe, dc)), 
            		(baseA.getLongitude().add(
            				baseA.getLongitude().add(meta.lonMetersAngle(lenght, lat, lon,  globe, dc))
            				).divide(2)), height);//cd
            
            Position posizD= new Position(baseA.getLatitude().add(meta.latMetersAngle(width, lat, lon,  globe, dc)), baseA.getLongitude(), height);//d
            
            Position posizAD= new Position(
            		(baseA.getLatitude().add(baseA.getLatitude().add(meta.latMetersAngle(width, lat, lon,  globe, dc)))).divide(2), 
            				baseA.getLongitude(), 
            				height);
            
            positions1cal.add(baseA); 
            positions1cal.add(posizAB);
            positions1cal.add(posizB);
            positions1cal.add(posizBC);
            positions1cal.add(posizC); 
            positions1cal.add(posizCD);
            positions1cal.add(posizD);
            positions1cal.add(posizAD);
  
            //convert double in angle
	        Angle slopeA=Angle.fromDegrees(slope);
	        
	        //calculus the roof height from roof slope
	        double roofheight=width/2*slopeA.multiply(2).tanHalfAngle();	 
	       
	        switch(aspect)
	        { 
	        	case 180:   //nord  
	        	case 0: //sud	
	        		posizBC=posizBC.add(Position.fromDegrees(0,0,roofheight));
	        		posizAD=posizAD.add(Position.fromDegrees(0,0,roofheight));	        		
	        		positions1cal.set(3, posizBC);
	        		positions1cal.set(7, posizAD);
	        		ArrayList<Position> positions1North = new ArrayList<Position>(); 
	        		positions2n.add(positions1cal.get(3));
	        		positions2n.add(positions1cal.get(4));
	        		positions2n.add(positions1cal.get(6));
	        		positions2n.add(positions1cal.get(7));

	        		ArrayList<Position> positions1South = new ArrayList<Position>(); 
	        		positions2s.add(positions1cal.get(0));
	        		positions2s.add(positions1cal.get(2));
	        		positions2s.add(positions1cal.get(3));
	        		positions2s.add(positions1cal.get(7));	        		
			    break;
	        	case 90:  //east
	        	case 270: //west
	        		posizAB=posizAB.add(Position.fromDegrees(0,0,roofheight));
	        		posizCD=posizCD.add(Position.fromDegrees(0,0,roofheight));
	        		positions1cal.set(1, posizAB);
	        		positions1cal.set(5, posizCD);
	        		ArrayList<Position> positions1East = new ArrayList<Position>(); 
	        		positions2e.add(positions1cal.get(1));
	        		positions2e.add(positions1cal.get(2));
	        		positions2e.add(positions1cal.get(4));
	        		positions2e.add(positions1cal.get(5));
	        		ArrayList<Position> positions1West = new ArrayList<Position>(); 
	        		positions2w.add(positions1cal.get(1));
	        		positions2w.add(positions1cal.get(5));
	        		positions2w.add(positions1cal.get(6));
	        		positions2w.add(positions1cal.get(0));		        		
	        	break;
	        }
	        
		}
		
		public Position getBaricenter(ArrayList<Position> positionList)
		{	/** calculate the barycenter from a list of positions*/
			
    		Position center = null;
			Angle aveLon= Angle.fromDegrees(0);
			Angle aveLat= Angle.fromDegrees(0);
			double aveHeight=0;
    		for(int i=0;i<positionList.size();i++)
    		{	   	        			

    			aveLon=aveLon.add(positionList.get(i).getLongitude().divide((positionList.size())));
    			aveLat=aveLat.add(positionList.get(i).getLatitude().divide((positionList.size())));
    			aveHeight=aveHeight+(positionList.get(i).getElevation()/positionList.size());
    			center = new Position(aveLat, aveLon, aveHeight);	   			
    		}
    		return center;  		
		}			
}



