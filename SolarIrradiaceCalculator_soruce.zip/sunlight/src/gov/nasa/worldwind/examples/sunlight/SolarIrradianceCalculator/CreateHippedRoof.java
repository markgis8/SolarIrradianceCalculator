package gov.nasa.worldwind.examples.sunlight.SolarIrradianceCalculator;

import java.awt.Color;

import gov.nasa.worldwind.WorldWindow;
import gov.nasa.worldwind.globes.Globe;
import gov.nasa.worldwind.render.BasicShapeAttributes;
import gov.nasa.worldwind.render.DrawContext;
import gov.nasa.worldwind.render.ExtrudedPolygon;
import gov.nasa.worldwind.render.Material;
import gov.nasa.worldwind.render.ShapeAttributes;
import gov.nasa.worldwindx.examples.LayerPanel;
/**
 * Copyright (C) 2001 United States Government
 * as represented by the Administrator of the
 * National Aeronautics and Space Administration.
 * All Rights Reserved.
 * @author  Marco Piragnolo
 * Cirgeo, University of Padua, francesco.pirotti@unipd.it, marco.piragnolo@unipd.it
 * @version 0.1  2014-29-05 11:46
 */

class CreateHippedNorth extends Building{
	/** Create a building with a Hipped roof to north*/
	public CreateHippedNorth (double lat, double lon,
			double lenght, double width, double height,
			double slope, int aspect, int aspectSide, Globe globe,
			WorldWindow wwd, LayerPanel layerPanel, DrawContext dc) 
	{
		
		super(lat, lon, lenght, width, height, slope, aspect, aspectSide, globe, wwd, layerPanel, dc);
		calculateHippedRoof();			
		
		
			ShapeAttributes sideAttributes = new BasicShapeAttributes();
            sideAttributes.setInteriorMaterial(new Material(new Color(255, 255, 210)));             
            sideAttributes.setOutlineOpacity(1);
            sideAttributes.setInteriorOpacity(1);
            sideAttributes.setOutlineMaterial(Material.BLACK);
            sideAttributes.setOutlineWidth(2);
            sideAttributes.setDrawOutline(true);
            sideAttributes.setDrawInterior(true);
            sideAttributes.setEnableLighting(true);

            ShapeAttributes capAttributes = new BasicShapeAttributes(sideAttributes);
            capAttributes.setInteriorMaterial(new Material(new Color(172, 36, 48)));           
            capAttributes.setInteriorOpacity(1);
            ExtrudedPolygon  poly4n = new ExtrudedPolygon (positions4n);
            poly4n.setSideAttributes(sideAttributes);         
            poly4n.setCapAttributes(capAttributes);
            poly4n.setAltitudeMode(2);           
            setPolygon(poly4n); 
            
	        switch(aspect)
	        { 
	        	case 180: //north   	        		
	        	case 0: //south	
	        		computeNormalBuilding(positions4n.get(2), positions4n.get(3), positions4n.get(0), getBaricenter(positions4n));
	        	break;	
	        	case 90:  //east
	        	case 270: //west
	        		computeNormalBuilding(positions4n.get(0), positions4n.get(1), positions4n.get(2), getBaricenter(positions4n));
	        	break;
	        } 
      }	
}

class CreateHippedSouth extends Building{
	/** Create a building with a Hipped roof to south*/
	public CreateHippedSouth(double lat, double lon,
			double lenght, double width, double height,
			double slope, int aspect, int aspectSide, Globe globe,
			WorldWindow wwd, LayerPanel layerPanel, DrawContext dc) 
	{
		
		super(lat, lon, lenght, width, height, slope, aspect,  aspectSide, globe, wwd, layerPanel, dc);
		calculateHippedRoof();
		this.aspectSide=aspectSide;
		
			ShapeAttributes sideAttributes = new BasicShapeAttributes();
            sideAttributes.setInteriorMaterial(new Material(new Color(172, 36, 48)));           
            sideAttributes.setOutlineOpacity(1);
            sideAttributes.setInteriorOpacity(1);
            sideAttributes.setOutlineMaterial(Material.BLACK);
            sideAttributes.setOutlineWidth(2);
            sideAttributes.setDrawOutline(true);
            sideAttributes.setDrawInterior(true);
            sideAttributes.setEnableLighting(true);
          
            ShapeAttributes capAttributes = new BasicShapeAttributes(sideAttributes);
            capAttributes.setInteriorMaterial(new Material(new Color(255, 255, 210)));    
            capAttributes.setInteriorOpacity(1);
            ExtrudedPolygon  poly4s = new ExtrudedPolygon (positions4s);           
            poly4s.setCapAttributes(sideAttributes);  
            poly4s.setSideAttributes(capAttributes);     
            poly4s.setAltitudeMode(2);
            setPolygon(poly4s);
            
	        switch(aspect)
	        { 
	        	case 180: //north  
	        	case 0: //south	
	        		computeNormalBuilding(positions4s.get(3), positions4s.get(2), positions4s.get(1), getBaricenter(positions4s));
	        	break;		    	       	
	        	case 90:  //east
	        	case 270: //west	
	        		computeNormalBuilding(positions4s.get(2), positions4s.get(1), positions4s.get(0), getBaricenter(positions4s));
	        	break;
	        }	

	  }
}
  
class CreateHippedWest extends Building{
	/** Create a building with a Hipped roof to west*/
	public CreateHippedWest(double lat, double lon,
			double lenght, double width, double height,
			double slope, int aspect, int aspectSide, Globe globe,
			WorldWindow wwd, LayerPanel layerPanel, DrawContext dc) {
		super(lat, lon, lenght, width, height, slope, aspect, aspectSide,  globe, wwd, layerPanel, dc);
		calculateHippedRoof();
		this.aspectSide=aspectSide;
		
			ShapeAttributes sideAttributes = new BasicShapeAttributes();
            sideAttributes.setInteriorMaterial(new Material(new Color(255, 255, 210)));             
            sideAttributes.setOutlineOpacity(1);
            sideAttributes.setInteriorOpacity(1);
            sideAttributes.setOutlineMaterial(Material.BLACK);
            sideAttributes.setOutlineWidth(2);
            sideAttributes.setDrawOutline(true);
            sideAttributes.setDrawInterior(true);
            sideAttributes.setEnableLighting(true);

            ShapeAttributes capAttributes = new BasicShapeAttributes(sideAttributes);
            capAttributes.setInteriorMaterial(new Material(new Color(172, 36, 48)));            
            capAttributes.setInteriorOpacity(1);
            ExtrudedPolygon  poly4w = new ExtrudedPolygon (positions4w);
            poly4w.setSideAttributes(sideAttributes);         
            poly4w.setCapAttributes(capAttributes);
            poly4w.setAltitudeMode(2);
            setPolygon(poly4w);
	        switch(aspect)
	        { 
	        	case 180: //north  
	        	case 0: //south			      
		             computeNormalBuilding(positions4w.get(2), positions4w.get(1), positions4w.get(0), getBaricenter(positions4w));
	        	break;	
	        	case 90:  //east
	        	case 270: //west
	        		 computeNormalBuilding(positions4w.get(1), positions4w.get(2), positions4w.get(0), getBaricenter(positions4w));		           	                
	        	break;
	        }	  

	  }
}
    
class CreateHippedEast extends Building{
	/** Create a building with a Hipped roof to east*/
	public CreateHippedEast(double lat, double lon,
			double lenght, double width, double height,
			double slope, int aspect, int aspectSide, Globe globe,
			WorldWindow wwd, LayerPanel layerPanel, DrawContext dc) 
	{
		super(lat, lon, lenght, width, height, slope, aspect, aspectSide,  globe, wwd, layerPanel, dc);
		calculateHippedRoof();
		this.aspectSide=aspectSide;
		
			ShapeAttributes sideAttributes = new BasicShapeAttributes();
            sideAttributes.setInteriorMaterial(new Material(new Color(255, 255, 210)));           
            sideAttributes.setOutlineOpacity(1);
            sideAttributes.setInteriorOpacity(1);
            sideAttributes.setOutlineMaterial(Material.BLACK);
            sideAttributes.setOutlineWidth(2);
            sideAttributes.setDrawOutline(true);
            sideAttributes.setDrawInterior(true);
            sideAttributes.setEnableLighting(true);

            ShapeAttributes capAttributes = new BasicShapeAttributes(sideAttributes);
            capAttributes.setInteriorMaterial(new Material(new Color(172, 36, 48)));            
            capAttributes.setInteriorOpacity(1);
            ExtrudedPolygon  poly4e = new ExtrudedPolygon (positions4e);
            poly4e.setSideAttributes(sideAttributes);         
            poly4e.setCapAttributes(capAttributes);
            poly4e.setAltitudeMode(2);
            setPolygon(poly4e);
	        switch(aspect)
	        { 
	        	case 180: //north  
	        	case 0: //south	
	                computeNormalBuilding(positions4e.get(0), positions4e.get(1), positions4e.get(2), getBaricenter(positions4e));				            
	        	break;	
	        	case 90:  //east
	        	case 270: //west
	        		computeNormalBuilding(positions4e.get(0), positions4e.get(2), positions4e.get(1), getBaricenter(positions4e));
	        	break;
	        }

	  }
}
