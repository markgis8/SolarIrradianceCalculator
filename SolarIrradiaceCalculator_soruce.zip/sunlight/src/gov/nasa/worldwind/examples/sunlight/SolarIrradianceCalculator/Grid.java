package gov.nasa.worldwind.examples.sunlight.SolarIrradianceCalculator;

import gov.nasa.worldwind.WorldWind;
import gov.nasa.worldwind.WorldWindow;
import gov.nasa.worldwind.examples.sunlight.SolarIrradianceCalculator.SunShading.AppFrame;
import gov.nasa.worldwind.geom.Angle;
import gov.nasa.worldwind.geom.Extent;
import gov.nasa.worldwind.geom.Intersection;
import gov.nasa.worldwind.geom.Line;
import gov.nasa.worldwind.geom.Position;
import gov.nasa.worldwind.geom.Sector;
import gov.nasa.worldwind.geom.Vec4;
import gov.nasa.worldwind.globes.Globe;
import gov.nasa.worldwind.layers.MarkerLayer;
import gov.nasa.worldwind.layers.RenderableLayer;
import gov.nasa.worldwind.render.BasicShapeAttributes;
import gov.nasa.worldwind.render.DrawContext;
import gov.nasa.worldwind.render.ExtrudedPolygon;
import gov.nasa.worldwind.render.Material;
import gov.nasa.worldwind.render.Path;
import gov.nasa.worldwind.render.PointPlacemark;
import gov.nasa.worldwind.render.PointPlacemarkAttributes;
import gov.nasa.worldwind.render.Renderable;
import gov.nasa.worldwind.render.ShapeAttributes;
import gov.nasa.worldwind.render.SurfacePolygon;
import gov.nasa.worldwind.render.SurfaceText;
import gov.nasa.worldwind.render.markers.BasicMarker;
import gov.nasa.worldwind.render.markers.BasicMarkerAttributes;
import gov.nasa.worldwind.render.markers.BasicMarkerShape;
import gov.nasa.worldwind.render.markers.Marker;
import gov.nasa.worldwind.render.markers.MarkerAttributes;
import gov.nasa.worldwind.terrain.HighResolutionTerrain;
import gov.nasa.worldwind.terrain.Terrain;
import gov.nasa.worldwind.util.BasicDragger;
import gov.nasa.worldwind.util.BufferFactory;
import gov.nasa.worldwind.util.BufferWrapper;
import gov.nasa.worldwind.util.WWMath;
import gov.nasa.worldwindx.examples.ApplicationTemplate;
import gov.nasa.worldwindx.examples.LayerPanel;
import java.awt.Color;
import java.awt.Point;
import java.text.DecimalFormat;
import java.text.FieldPosition;
import java.text.Format;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import javax.swing.SwingUtilities;

/**
 * Copyright (C) 2001 United States Government
 * as represented by the Administrator of the
 * National Aeronautics and Space Administration.
 * All Rights Reserved.
 * @author  Marco Piragnolo
 * Cirgeo, University of Padua, francesco.pirotti@unipd.it, marco.piragnolo@unipd.it
 * @version 0.1  2014-29-05 11:46
 */

public class Grid {
	/**Create the grid, add layer and perform the analysis for analysis*/
	private DrawContext dc;
	private WorldWindow wwd;
	private Globe globe;   
	private double lat;
	private double lon;
	private double elev=0;

	// cell dimension
	private double xymeter=0; 
	// wight of matrix
	private static int NUM_POINTS_WIDE=0;
	// height of matrix
    private static int NUM_POINTS_HIGH=0; 
    //key for building list
    private Integer key; 

    protected static final Double TARGET_RESOLUTION = 10d;
    
    // static PointPlacemark pointGrid;
	private LayerPanel layerPanel;
	//private RenderableLayer layer = new RenderableLayer();
	private RenderableLayer glayer = new RenderableLayer();
	private RenderableLayer rlayer = new RenderableLayer();
	private RenderableLayer mlayer = new RenderableLayer();
	private RenderableLayer resultlayerTerrainInt = new RenderableLayer();
	private RenderableLayer resultlayerTerrainPath = new RenderableLayer();
	private RenderableLayer resultlayerObjectInt = new RenderableLayer();
	private RenderableLayer resultlayerObjectSideInt = new RenderableLayer();
	private RenderableLayer resultlayerObjectPath= new RenderableLayer();
	private RenderableLayer resultlayerRoofInt= new RenderableLayer();
	private RenderableLayer resultlayerRoofPath= new RenderableLayer();
	private RenderableLayer resultlayerRoofShadowInt= new RenderableLayer();
	private RenderableLayer resultlayerRoofShadowPath= new RenderableLayer();
	private  RenderableLayer analyticSurfaceLayer= new RenderableLayer();
	private  RenderableLayer analyticSurfaceLayerRoof= new RenderableLayer();
	private  RenderableLayer analyticSurfaceLayerMerge= new RenderableLayer();
    //create sun raylight object
	private DrawSolarRay drawsunray = new DrawSolarRay();

	private List<Double> groundAnalytic = new ArrayList<Double>();
	private List<Double> roofAnalytic = new ArrayList<Double>();
	private List<Double> mergeAnalytic = new ArrayList<Double>();
	private Position posCheck;
	private static final double MISSING_DATA_SIGNAL = (double) Short.MIN_VALUE;
    protected static final double HUE_BLUE = 240d / 360d;
    protected static final double HUE_RED = 0d / 360d;
	List<Position> gridcorners = new ArrayList<Position>();
	
		public Grid(double lat, double lon, Globe globe, WorldWindow wwd, LayerPanel layerPanel)
	    {
	        this.wwd=wwd;
			this.globe= globe;
	        this.layerPanel=layerPanel;   
	            
	    }
		//---------------------------------------------------------------------
		
		//Layer for grid values of the ground
		public void insertGroundPointGridLayer()
		{	/** insert a layer that contains the grid */
			wwd.addSelectListener(new BasicDragger(wwd));
	        //add layers
	        glayer.isEnabled();
	        glayer.setPickEnabled(true);  
	        glayer.setName("Ground Grid");
	        SunShading.insertBeforeCompass(this.wwd, glayer);
	        this.layerPanel.update(this.wwd);
	    }
		
		private  void insertGroundPointGrid(PointPlacemark pointGrid)
		{	/** insert the grid placemark to grid's layer */					
			RenderableLayer layer=(RenderableLayer) wwd.getModel().getLayers().getLayerByName("Ground Grid");
			layer.addRenderable(pointGrid); 
			wwd.getModel().getLayers().remove("Ground Grid");
	        this.layerPanel.update(this.wwd);
		}
		//---------------------------------------------------------------------
		
		//Layer for ground analytic surface
		public void insertGroundAnalyticLayer()
		{	/** insert a layer that contains the grid */
			wwd.addSelectListener(new BasicDragger(wwd));
	        //add layers
	    	analyticSurfaceLayer.setPickEnabled(false);
	    	analyticSurfaceLayer.setName("Analytic Surfaces Ground");
	    	analyticSurfaceLayer.setMinActiveAltitude(1);	       
	        SunShading.insertBeforeCompass(this.wwd, analyticSurfaceLayer);	       
	        this.layerPanel.update(this.wwd);
	    }
		//---------------------------------------------------------------------
		
		//Layer for roofs analytic surface
		public void insertRoofAnalyticLayer()
		{	/** insert a layer that contains the grid */
			wwd.addSelectListener(new BasicDragger(wwd));
	        //add layers
	    	analyticSurfaceLayerRoof.setPickEnabled(false);
	    	analyticSurfaceLayerRoof.setName("Analytic Surfces Roof");
	    	analyticSurfaceLayerRoof.setMinActiveAltitude(1);	        
	        SunShading.insertBeforeCompass(this.wwd, analyticSurfaceLayerRoof);
	        this.layerPanel.update(this.wwd);
	    }
		//---------------------------------------------------------------------
				
		//Layer for grid values of the roof
		public void insertRoofPointGridLayer()
		{	/** insert a layer that contains the grid */
			wwd.addSelectListener(new BasicDragger(wwd));
	        //add layers
	        rlayer.setEnabled(false);
	        rlayer.setPickEnabled(true);  
	        rlayer.setName("Roof Grid");
	        SunShading.insertBeforeCompass(this.wwd, rlayer);
	        this.layerPanel.update(this.wwd);
	    }
		
		private  void insertRoofPointGrid(PointPlacemark pointGrid)
		{	/** insert the grid placemark to grid's layer */					
			RenderableLayer layer=(RenderableLayer) wwd.getModel().getLayers().getLayerByName("Roof Grid");
			layer.addRenderable(pointGrid); 
			wwd.getModel().getLayers().remove("Roof Grid");
	        this.layerPanel.update(this.wwd);
		}
		//---------------------------------------------------------------------
				
		//Layer for grid values of the ground+roofs
		public void insertMergePointGridLayer()
		{	/** insert a layer that contains the grid */
			wwd.addSelectListener(new BasicDragger(wwd));
	        //add layers
	        mlayer.setEnabled(false);
	        mlayer.setPickEnabled(true);  						
	        mlayer.setName("Merge Grid");
	        SunShading.insertBeforeCompass(this.wwd, mlayer);
	        this.layerPanel.update(this.wwd);
	    }
		
		private  void insertMergePointGrid(PointPlacemark pointGrid)
		{	/** insert the grid placemark to grid's layer */					
			RenderableLayer layer=(RenderableLayer) wwd.getModel().getLayers().getLayerByName("Merge Grid");
			layer.addRenderable(pointGrid); 
			wwd.getModel().getLayers().remove("Merge Grid");
	        this.layerPanel.update(this.wwd);
		}
		//---------------------------------------------------------------------
		
		//Layer for ground+roofs analytic surface
		public void insertMergeAnalyticLayer()
		{	/** insert a layer that contains the grid */
			wwd.addSelectListener(new BasicDragger(wwd));
	        //add layers
	    	analyticSurfaceLayerMerge.setPickEnabled(false);
	    	analyticSurfaceLayerMerge.setName("Analytic Surfces Merge");
	    	analyticSurfaceLayerMerge.setMinActiveAltitude(1);	        
	        SunShading.insertBeforeCompass(this.wwd, analyticSurfaceLayerMerge);
	        this.layerPanel.update(this.wwd);
	    }
		//---------------------------------------------------------------------
		
		//Layer for the shadows of the elevation on the ground
		public void insertResultTerreainIntLayer()
		{
			wwd.addSelectListener(new BasicDragger(wwd));
	        //add layers
	        resultlayerTerrainInt.setEnabled(false);
	        resultlayerTerrainInt.setPickEnabled(true);  
	        resultlayerTerrainInt.setName("Shadow of terrain");
	        SunShading.insertBeforeCompass(this.wwd, resultlayerTerrainInt);
	        this.layerPanel.update(this.wwd);
		}
		
		private  void insertResultTerreainInt(PointPlacemark resultPoint)
		{	/** insert the grid placemark to grid's layer */					
			RenderableLayer layer=(RenderableLayer) wwd.getModel().getLayers().getLayerByName("Shadow of terrain");
			layer.addRenderable(resultPoint); 
			//wwd.getModel().getLayers().remove("Result");
	        this.layerPanel.update(this.wwd);
		}
		//---------------------------------------------------------------------
		
		//Layer for the shadows path of the elevation on the ground
		public void insertResultTerreainPathLayer()
		{
			wwd.addSelectListener(new BasicDragger(wwd));
	        //add layers
	        resultlayerTerrainPath.setEnabled(false);
	        resultlayerTerrainPath.setPickEnabled(true);  
	        resultlayerTerrainPath.setName("Shadow of terrain Path");
	        SunShading.insertBeforeCompass(this.wwd, resultlayerTerrainPath);
	        this.layerPanel.update(this.wwd);
		}
		
		private  void insertResultTerreainPath(Path path)
		{	/** insert the grid placemark to grid's layer */					
			RenderableLayer layer=(RenderableLayer) wwd.getModel().getLayers().getLayerByName("Shadow of terrain Path");
			layer.addRenderable(path); 
			//wwd.getModel().getLayers().remove("Result");
	        this.layerPanel.update(this.wwd);
		}
		//---------------------------------------------------------------------
		
		//Layer for shadows of objects with terrain
		public void insertResultObjectIntLayer()
		{
			wwd.addSelectListener(new BasicDragger(wwd));
	        //add layers
			resultlayerObjectInt.setEnabled(false);
			resultlayerObjectInt.setPickEnabled(true);  
			resultlayerObjectInt.setName("Shadow of Object with terrain");
	        SunShading.insertBeforeCompass(this.wwd, resultlayerObjectInt);
	        this.layerPanel.update(this.wwd);
		}
		
		private  void insertResultObjectInt(PointPlacemark resultPoint)
		{	/** insert the grid placemark to grid's layer */					
			RenderableLayer layer=(RenderableLayer) wwd.getModel().getLayers().getLayerByName("Shadow of Object with terrain");
			layer.addRenderable(resultPoint); 
			//wwd.getModel().getLayers().remove("Result");
	        this.layerPanel.update(this.wwd);
		}
		//---------------------------------------------------------------------
		
		//Layer for shadows of objects with the side of other object
		public void insertResultObjectSideIntLayer()
		{
			wwd.addSelectListener(new BasicDragger(wwd));	     
			resultlayerObjectSideInt.setEnabled(false);;
			resultlayerObjectSideInt.setPickEnabled(true);  
			resultlayerObjectSideInt.setName("Side of Object");
	        SunShading.insertBeforeCompass(this.wwd, resultlayerObjectSideInt);
	        this.layerPanel.update(this.wwd);
		}
		
		private  void insertResultObjectSideInt(PointPlacemark resultSidePoint)
		{	/** insert the grid placemark to grid's layer */					
			RenderableLayer layer=(RenderableLayer) wwd.getModel().getLayers().getLayerByName("Side of Object");
			layer.addRenderable(resultSidePoint); 
			//wwd.getModel().getLayers().remove("Result");
	        this.layerPanel.update(this.wwd);
		}
		//---------------------------------------------------------------------
		
		//Layer for the path of objects' shadows with terrain
		public void insertResultObjectPathLayer()
		{
			wwd.addSelectListener(new BasicDragger(wwd));
	        //add layers
			resultlayerObjectPath.setEnabled(false);
			resultlayerObjectPath.setPickEnabled(true);  
			resultlayerObjectPath.setName("Shadow Object terr Path");
	        SunShading.insertBeforeCompass(this.wwd, resultlayerObjectPath);
	        this.layerPanel.update(this.wwd);
		}
		
		private  void insertResultObjectPath(Path path)
		{	/** insert the grid placemark to grid's layer */					
			RenderableLayer layer=(RenderableLayer) wwd.getModel().getLayers().getLayerByName("Shadow Object terr Path");
			layer.addRenderable(path); 
			//wwd.getModel().getLayers().remove("Result");
	        this.layerPanel.update(this.wwd);
		}
		//---------------------------------------------------------------------
		
		//Layer for the roof points 
		public void insertResultRoofIntLayer()
		{	/** insert roof's point intersection layer */
			wwd.addSelectListener(new BasicDragger(wwd));
	        //add layers
			resultlayerRoofInt.setEnabled(false);
			resultlayerRoofInt.setPickEnabled(true);  
			resultlayerRoofInt.setName("Roof Inters");
	        SunShading.insertBeforeCompass(this.wwd, resultlayerRoofInt);
	        this.layerPanel.update(this.wwd);
		}
		
		private  void insertResultRoofInt(PointPlacemark resultPoint)
		{	/** insert the roof placemark  */					
			RenderableLayer layer=(RenderableLayer) wwd.getModel().getLayers().getLayerByName("Roof Inters");
			layer.addRenderable(resultPoint); 
			//wwd.getModel().getLayers().remove("Result");
	        this.layerPanel.update(this.wwd);
		}
		//---------------------------------------------------------------------
		
		//Layer for the roof points path
		public void insertResultRoofPathLayer()
		{	/** insert roof's point intersection path layer */
			wwd.addSelectListener(new BasicDragger(wwd));
	        //add layers
			resultlayerRoofPath.setEnabled(false);
			resultlayerRoofPath.setPickEnabled(true);  
			resultlayerRoofPath.setName("Roof Inters Path");
	        SunShading.insertBeforeCompass(this.wwd, resultlayerRoofPath);
	        this.layerPanel.update(this.wwd);
		}
		
		private  void insertResultRoofPath(Path path)
		{	/** insert the roof's intersection path */					
			RenderableLayer layer=(RenderableLayer) wwd.getModel().getLayers().getLayerByName("Roof Inters Path");
			layer.addRenderable(path); 
			//wwd.getModel().getLayers().remove("Result");
	        this.layerPanel.update(this.wwd);
		}
		//---------------------------------------------------------------------
		
		//Layer for the shadows on the roof
		public void insertResultRoofShadowIntLayer()
		{	/**	insert layer for shadow on the roof*/
			wwd.addSelectListener(new BasicDragger(wwd));
	        //add layers
			resultlayerRoofShadowInt.setEnabled(false);
			resultlayerRoofShadowInt.setPickEnabled(true);  
			resultlayerRoofShadowInt.setName("Roof Shadow Inters");
	        SunShading.insertBeforeCompass(this.wwd, resultlayerRoofShadowInt);
	        this.layerPanel.update(this.wwd);
		}
		
		private  void insertResultRoofShadowInt(PointPlacemark resultPoint)
		{	/** insert the grid placemark */					
			RenderableLayer layer=(RenderableLayer) wwd.getModel().getLayers().getLayerByName("Roof Shadow Inters");
			layer.addRenderable(resultPoint); 
			//wwd.getModel().getLayers().remove("Result");
	        this.layerPanel.update(this.wwd);
		}
		//---------------------------------------------------------------------
		
		
		//Layer for the shadows path on the roof
		public void insertResultRoofShadowPathLayer()
		{	/**Layer for the shadows path on the roof*/
			wwd.addSelectListener(new BasicDragger(wwd));
	        //add layers
			resultlayerRoofShadowPath.setEnabled(false);
			resultlayerRoofShadowPath.setPickEnabled(true);  
			resultlayerRoofShadowPath.setName("Roof Shadow Inters Path"); 
	        SunShading.insertBeforeCompass(this.wwd, resultlayerRoofShadowPath);
	        this.layerPanel.update(this.wwd);
		}
		
		private  void insertResultRoofShadowPath(Path path)
		{	/** insert the shadow path */					
			RenderableLayer layer=(RenderableLayer) wwd.getModel().getLayers().getLayerByName("Roof Shadow Inters Path");
			layer.addRenderable(path); 
			//wwd.getModel().getLayers().remove("Result");
	        this.layerPanel.update(this.wwd);
		}
		//---------------------------------------------------------------------		

		
	    public void createGrid(double xm, int xgrid, int ygrid,double lat, double lon, double rho, int cloud)
	    {   
	    	/** Create the grid and its positions. This one is rectangular; it need not be, but must be four-sided.*/
	    	this.lat=lat;
	    	this.lon=lon;   	
	    	this.xymeter=xm;	    	
	    	NUM_POINTS_WIDE=xgrid;
	    	NUM_POINTS_HIGH=ygrid;
	    	MeterToAngle metA=new MeterToAngle();
	    	
	    	Position base=new Position(Position.fromDegrees(lat, lon), elev);
	        gridcorners.add(base);
	        gridcorners.add(new Position(base.getLatitude(), base.getLongitude().add(metA.lonMetersAngle(xymeter, lat, lon, globe, dc).multiply(NUM_POINTS_WIDE)), elev));      
	        gridcorners.add(new Position(base.getLatitude().add(metA.latMetersAngle(xymeter, lat, lon, globe, dc).multiply(NUM_POINTS_HIGH)), base.getLongitude().add(metA.lonMetersAngle(xymeter, lat, lon, globe, dc).multiply(NUM_POINTS_WIDE)), elev));    
	        gridcorners.add(new Position(base.getLatitude().add(metA.latMetersAngle(xymeter, lat, lon, globe, dc).multiply(NUM_POINTS_HIGH)), base.getLongitude(),elev));  
	        	      
	        boundingBox(gridcorners, lat, lon, xm, NUM_POINTS_WIDE, NUM_POINTS_HIGH);  
	       	      
	        int aDataValue = 0;// generate an arbitrary data value
	        String labeltext=null;
	        PositionIterator iter = new PositionIterator(gridcorners, NUM_POINTS_WIDE, NUM_POINTS_HIGH);

	        //insert each single layer
	        insertResultTerreainIntLayer();
	        insertResultTerreainPathLayer();
	        insertResultObjectIntLayer();
	        insertResultObjectSideIntLayer();
	        insertResultObjectPathLayer();
	        insertResultRoofIntLayer();
	        insertResultRoofPathLayer();
	        insertResultRoofShadowIntLayer();	      
	        insertResultRoofShadowPathLayer();
	        insertGroundPointGridLayer();
	        insertRoofPointGridLayer();
	        insertMergePointGridLayer();
	        //insert the layer for beam of light 
	        drawsunray.insertSolarRayLayer(wwd);
	        
	        //create object 
	        PointObject groundPointObject = new PointObject();
	        PointObject roofPointObject = new PointObject();
	        PointObject mergePointObject = new PointObject();
     
	        //array list of roof point got by the projection of ground point
	        ArrayList <Position> roofCheck= new ArrayList<Position>();
	        Position roofPosition;
	        
	        while (iter.hasNext()) 
	        {   	  	        	
	        	
	            Position position = iter.next();    	            
	            
	            double elevP=SunShading.AppFrame.getHighResolutionTerrain().getElevation(position);	
	            
	            AspectSlopeTerrCalc astcalc = new  AspectSlopeTerrCalc(SunShading.AppFrame.getGlobe(), wwd, position);	                              		              
		    	         	            
	            BasicSunPositionProvider bspp = new BasicSunPositionProvider();                  
	           
	            //Compute incidence angle of each terrain points
	            double incidenceCal=AdvancedSunCalculator.subsolarIncidence(bspp.getCalendar(), position, elevP,  astcalc.getAspectTerrain().degrees, astcalc.getSlopeTerrain().degrees);                                		      
	           
				//--1
				//set the basic values of each terrain points	            
	            
	            groundPointObject.setPointValues(position.getLatitude().getDegrees(), position.getLongitude().getDegrees(), elevP,  astcalc.getSlopeTerrain().degrees,  astcalc.getAspectTerrain().degrees, incidenceCal);	 
	           
	            roofPointObject.setPointValues(position.getLatitude().getDegrees(), position.getLongitude().getDegrees(),0,0,0,90);
	           
	            mergePointObject.setPointValues(position.getLatitude().getDegrees(), position.getLongitude().getDegrees(), elevP,  astcalc.getSlopeTerrain().degrees,  astcalc.getAspectTerrain().degrees, incidenceCal);	 
	            	            	           	            
            
				//--2	
				//compute the shadow of the high elevations on ground and if found, set incidence 0	
				//------------------------------------------//
				// groundPointObject  and mergePointObject //
				//----------------------------------------//	          	        	
	          	shadowOfElevationOnGround(position, groundPointObject, mergePointObject);
	           
	          	//create a iterator for the buildings 
	            Iterator<?> itr2 = AppFrame.getlistOfBuilding().getBuildingHash().keySet().iterator();
	        	while(itr2.hasNext())
	        	{	  
	        		key = (Integer)itr2.next();
	        		
	        		Building edif = (Building) AppFrame.getlistOfBuilding().getBuildingHash().get(key);
	        		
	        		ExtrudedPolygon poly = edif.getPolygon();
	        		
	        		//labeltext="lon: \n"+position.getLatitude().degrees +" lat: \n"+ position.getLongitude().getDegrees()+" elev: \n"+this.elev+" slope: \n"+ edif.getSlope()+" aspect: \n"+ edif.getAspect()+" incidence: \n"+ edif.getincidence();	        		
	        		labeltext="Aspect: "+ Math.round(edif.getAspectSide());

	        		
	        		//--3				
	        		//compute the shadow of the buildings on the terrain and if found, set incidence 0	
	        		//---------------------------------------//
	        		// groundPointObject - mergePointObject //
	        		//-------------------------------------//
	        		shadowBuildOnTerrain(position, poly, groundPointObject, mergePointObject);
	        		

	        		//--4	        		
	        		//calculate roof points	  
	        		//----------------------------------------//
	        		// roofPointObject  and mergePointObject //
	        		//--------------------------------------//	        		
	        		
	        		roofIntersector(position, poly, labeltext, Math.round(edif.getincidence()), edif.getSlope(), edif.getAspectSide(), mergePointObject, roofPointObject, roofCheck);	
	        		
	        		//set values of the roof point object	     		
	        		roofPosition=new Position(position.getLatitude(), position.getLongitude(), roofPointObject.getPointElevation());
   		
	    
					//--5	
					//compute the shadow of the building on roofs and if found, set incidence 0	
					//------------------------------------------//
					// roofPointObject  and mergePointObject   //
					//----------------------------------------//		        		
	        		shadowBuildOnRoof(position, roofPointObject, mergePointObject);

	        		
	        		//--6	
					//compute the shadow of the Elevation on roofs and if found, set incidence 0	
					//------------------------------------------//
					// roofPointObject  and mergePointObject //
					//----------------------------------------//	        		
	        		shadowOfElevationOnRoof(position, roofPointObject, mergePointObject);
	        	}        	
	        	
	        	AppFrame.getlistOfPosition().insertTerrainHash(aDataValue++, groundPointObject.createPointObject(position, groundPointObject.getIndicence()));

	        	double sunElevation=AdvancedSunCalculator.getElevation(bspp.getCalendar(), position, elevP,  astcalc.getAspectTerrain().degrees, astcalc.getSlopeTerrain().degrees);  	
	        	//calculate irradiance values
	            Irradiance irradiance = new Irradiance();
	            double dIrrG=irradiance.totIrradiance(groundPointObject.getIndicence(), groundPointObject.getSlope(), AdvancedSunCalculator.getObservedHourAngle(bspp.getCalendar(), position, elevP,  astcalc.getAspectTerrain().degrees, astcalc.getSlopeTerrain().degrees), rho, cloud, bspp.getCalendar().get(Calendar.DAY_OF_YEAR), elevP, sunElevation);
	            double dIrrR=irradiance.totIrradiance(roofPointObject.getIndicence(), roofPointObject.getSlope(), AdvancedSunCalculator.getObservedHourAngle(bspp.getCalendar(), position, elevP,  astcalc.getAspectTerrain().degrees, astcalc.getSlopeTerrain().degrees), rho, cloud, bspp.getCalendar().get(Calendar.DAY_OF_YEAR), elevP, sunElevation);
	            double dIrrM=irradiance.totIrradiance(mergePointObject.getIndicence(), mergePointObject.getSlope(), AdvancedSunCalculator.getObservedHourAngle(bspp.getCalendar(), position, elevP,  astcalc.getAspectTerrain().degrees, astcalc.getSlopeTerrain().degrees), rho, cloud, bspp.getCalendar().get(Calendar.DAY_OF_YEAR), elevP, sunElevation);
	        			          
	            insertGroundPointGrid(groundPointObject.createPointObject(position, dIrrG));           
	            insertRoofPointGrid(roofPointObject.createPointObject(position, dIrrR));
	            insertMergePointGrid(mergePointObject.createPointObject(position,  dIrrM));
	                           		           
	            // add values to analytic  surface
	            groundAnalytic.add(dIrrG);	           
	            roofAnalytic.add(dIrrR);	           
	            mergeAnalytic.add(dIrrM);
	           
	            //draw solar ray 
	            drawsunray.insertSolarRay(drawsunray.drawSolarRay(position));		           
	        }  
 
	        //draw analytic syrfaces
	        initAnalyticSurfaceLayer();
	    }
	    
	    public void roofIntersector(Position position, ExtrudedPolygon extPoly, String labeltext, double roofIncidence,  double slope, int aspect, PointObject mergePointObject, PointObject roofPointObject,  ArrayList <Position> roofCheck)
	    {    
	    	/**It projects the ground position on the building's roof and calculate the roof's point elevation(intersection point) */
	    	try
	        {
	    		posCheck=position;
	            // Create the line to intersect with the shape.
	            Position referencePosition = position;

	            Vec4 referencePoint = SunShading.AppFrame.getHighResolutionTerrain().getSurfacePoint(referencePosition);

	            Position targetPosition = new Position(referencePosition, 100);
	           
	            Vec4 targetPoint = SunShading.AppFrame.getHighResolutionTerrain().getSurfacePoint(targetPosition);
	            
	            Line line = new Line(targetPoint, referencePoint.subtract3(targetPoint));
         
	            // Perform the intersection.
	            List<Intersection> intersections = extPoly.intersect(line, SunShading.AppFrame.getHighResolutionTerrain());              
	            
	            if (intersections != null)
	            {	

	                for (Intersection intersection : intersections)
	                {       	                	
	                    Path path = new Path(referencePosition, targetPosition);
	                    ShapeAttributes pathAttributes = new BasicShapeAttributes();
	                    path.setAltitudeMode(WorldWind.RELATIVE_TO_GROUND);
	                    pathAttributes.setOutlineMaterial(Material.RED);
	                    pathAttributes.setOutlineOpacity(0.6);
	                    pathAttributes.setDrawOutline(true);
	                    pathAttributes.setDrawInterior(false);
	                    path.setAttributes(pathAttributes);  	                  
	                           	    	
	        	        PointPlacemark point = new PointPlacemark(	        	       
			        	        new Position(
			        					(SunShading.AppFrame.getGlobe().computePositionFromPoint(intersection.getIntersectionPoint()).getLatitude()), 
			        							(SunShading.AppFrame.getGlobe().computePositionFromPoint(intersection.getIntersectionPoint()).getLongitude()),
			        									(SunShading.AppFrame.getGlobe().computePositionFromPoint(intersection.getIntersectionPoint()).getElevation()-SunShading.AppFrame.getHighResolutionTerrain().getElevation(position)))
		        	        );          	        
	        	              	        
	        	        point.setAltitudeMode(WorldWind.RELATIVE_TO_GROUND); 	     
	        	        PointPlacemarkAttributes pointAttributes = new PointPlacemarkAttributes();
	        	        
	        	        pointAttributes.setUsePointAsDefaultImage(true);
	        	    	point.setAttributes(pointAttributes);   
	        	    	point.setLabelText(labeltext);
	        	    	pointAttributes.setLineMaterial(Material.RED); 
	        	    	pointAttributes.setScale(10.0);
	        	    	
	        	    	insertResultRoofInt(point);
	        	    	
	        	    	insertResultRoofPath(path);
	        	    	
	        	    	double eleva=SunShading.AppFrame.getGlobe().computePositionFromPoint(intersection.getIntersectionPoint()).getElevation()-SunShading.AppFrame.getHighResolutionTerrain().getElevation(position);                                     
        	    	
	        	    	roofPointObject.setLat(SunShading.AppFrame.getGlobe().computePositionFromPoint(intersection.getIntersectionPoint()).getLatitude().degrees);
	        	    	roofPointObject.setLon(SunShading.AppFrame.getGlobe().computePositionFromPoint(intersection.getIntersectionPoint()).getLongitude().degrees);	     	
	        	    	roofPointObject.setElevation(eleva);
	            		roofPointObject.setAspect(aspect);
	            		roofPointObject.setSlope(slope);
	            		roofPointObject.setIncidence(roofIncidence);
	            		
	            		mergePointObject.setLat(SunShading.AppFrame.getGlobe().computePositionFromPoint(intersection.getIntersectionPoint()).getLatitude().degrees);
	        	    	mergePointObject.setLon(SunShading.AppFrame.getGlobe().computePositionFromPoint(intersection.getIntersectionPoint()).getLongitude().degrees);	
	        	    	mergePointObject.setElevation(mergePointObject.getPointElevation()+eleva); 
	        	    	mergePointObject.setAspect(aspect);
	            		mergePointObject.setSlope(slope);
	            		mergePointObject.setIncidence(roofIncidence);	
	            		
	            		posCheck= intersection.getIntersectionPosition();
	            		}                
	            }
	            else{double eleva=0;roofPointObject.setElevation(eleva);}	            
	        }
	        catch (InterruptedException e)
	        {
	            e.printStackTrace();
	        }				     	
	    }
	    
	    public void shadowBuildOnTerrain(Position position, ExtrudedPolygon extPoly, PointObject groundPointObject, PointObject mergePointObject)
	    {   /**Calculate the building's shadows on ground*/       	
	    	try
	        {
	            // Create the line to intersect with the shape.

	            Vec4 startPoint = SunShading.AppFrame.getHighResolutionTerrain().getSurfacePoint(position);

	            Line line = new Line(startPoint, SunShading.AppFrame.getSunDirection());

	            List<Intersection> intersections = extPoly.intersect(line, SunShading.AppFrame.getHighResolutionTerrain());
	                       
	            // Get and display the intersections.
	            if (intersections != null)
	            {	

	                for (Intersection intersection : intersections)
	                {       	                   
	                    Path path = new Path(position, new Position(
	        					(SunShading.AppFrame.getGlobe().computePositionFromPoint(intersection.getIntersectionPoint()).getLatitude()), 
    							(SunShading.AppFrame.getGlobe().computePositionFromPoint(intersection.getIntersectionPoint()).getLongitude()),
    							(SunShading.AppFrame.getGlobe().computePositionFromPoint(intersection.getIntersectionPoint()).getElevation()-SunShading.AppFrame.getHighResolutionTerrain().getElevation(position)))
	                    		);
	                    ShapeAttributes pathAttributes = new BasicShapeAttributes();
	                    path.setAltitudeMode(WorldWind.RELATIVE_TO_GROUND);
	                    pathAttributes.setOutlineMaterial(Material.MAGENTA);
	                    pathAttributes.setOutlineOpacity(0.6);
	                    pathAttributes.setDrawOutline(true);
	                    pathAttributes.setDrawInterior(false);
	                    path.setAttributes(pathAttributes);  	                  	                    
	        	    	
	        	        PointPlacemark pointS = new PointPlacemark(	        	       
		        	        new Position(
		        					(SunShading.AppFrame.getGlobe().computePositionFromPoint(intersections.get(0).getIntersectionPoint()).getLatitude()), 
		        							(SunShading.AppFrame.getGlobe().computePositionFromPoint(intersections.get(0).getIntersectionPoint()).getLongitude()),
		        									(SunShading.AppFrame.getGlobe().computePositionFromPoint(intersections.get(0).getIntersectionPoint()).getElevation()-SunShading.AppFrame.getHighResolutionTerrain().getElevation(position)))
	        	        );

	        	        PointPlacemark pointI = new PointPlacemark(new Position(position.getLatitude(), position.getLongitude(), position.getElevation()+2)); 
	        	        
	        	            
	        	        PointPlacemarkAttributes pointAttributesI = new PointPlacemarkAttributes();
	        	        pointAttributesI.setUsePointAsDefaultImage(true);
	        	        pointAttributesI.setScale(20.0);
	        	    	pointAttributesI.setLineMaterial(Material.MAGENTA); 
	        	    	pointI.setAttributes(pointAttributesI);  
	        	    	
	        	        PointPlacemarkAttributes pointAttributesS = new PointPlacemarkAttributes();
	        	        pointAttributesS.setUsePointAsDefaultImage(true);
	        	        pointAttributesS.setScale(5.0);
	        	    	pointAttributesS.setLineMaterial(Material.ORANGE); 
	        	    	pointS.setAttributes(pointAttributesS);  
	        	    	pointS.setAltitudeMode(WorldWind.RELATIVE_TO_GROUND); 	
	        	    	pointS.setAttributes(pointAttributesS);   
	        	    	
	        	    	insertResultObjectInt(pointI);
	        	    	
	        	    	insertResultObjectSideInt(pointS);
	        	    	
	        	    	insertResultObjectPath(path);
	                }     
    	            groundPointObject.setIncidence(position.getLatitude().degrees, position.getLongitude().degrees, position.getElevation(), 90.0);
    	            mergePointObject.setIncidence(position.getLatitude().degrees, position.getLongitude().degrees, position.getElevation(), 90.0);
	            }

	        }
	        catch (InterruptedException e)
	        {
	            e.printStackTrace();
	        }				     	
	    }

	    public void shadowBuildOnRoof(Position position, PointObject roofPointObject, PointObject mergePointObject)
	    {    /**Calculate the building's shadows on roofs*/  			
	    	
	    	//create a new  iterator to compute a building with each others
	    	Iterator<?> itr4 = AppFrame.getlistOfBuilding().getBuildingHash().keySet().iterator();
	    	
        	while(itr4.hasNext())
        	{	  
        		Integer key = (Integer)itr4.next();
        		Building edif = (Building) AppFrame.getlistOfBuilding().getBuildingHash().get(key);
        		
        		ExtrudedPolygon poly4 = edif.getPolygon();
	             
					try {
						//filter to calculate only the roof point, not the ground ones
						if (posCheck.getElevation()>position.getElevation())
						{
							Position ooo = new Position(posCheck.getLatitude(), posCheck.getLongitude(), posCheck.getElevation()+0.5);
				            Vec4 startPoint = SunShading.AppFrame.getHighResolutionTerrain().getSurfacePoint(ooo);				          
				            Line line = new Line(startPoint ,  SunShading.AppFrame.getSunPosition());

				            List<Intersection> intersections = poly4.intersect(line, SunShading.AppFrame.getHighResolutionTerrain());					             
		    		  
				             if(intersections != null)
				             {  
				             	PointPlacemark pointR = new PointPlacemark(new Position(
				             			(SunShading.AppFrame.getGlobe().computePositionFromPoint(intersections.get(0).getIntersectionPoint()).getLatitude()), 
				             			(SunShading.AppFrame.getGlobe().computePositionFromPoint(intersections.get(0).getIntersectionPoint()).getLongitude()),
				             			(SunShading.AppFrame.getGlobe().computePositionFromPoint(intersections.get(0).getIntersectionPoint()).getElevation()-SunShading.AppFrame.getHighResolutionTerrain().getElevation(SunShading.AppFrame.getGlobe().computePositionFromPoint(intersections.get(0).getIntersectionPoint())))
				             			));
		         	        
				             	PointPlacemarkAttributes pointAttributesR = new PointPlacemarkAttributes();
			        	        pointAttributesR.setUsePointAsDefaultImage(true);
			        	        pointAttributesR.setScale(10.0);
			        	    	pointAttributesR.setLineMaterial(Material.BLUE); 
			        	    	pointR.setAttributes(pointAttributesR);  
			        	    	pointR.setAltitudeMode(WorldWind.RELATIVE_TO_GROUND); 
			        	    	insertResultRoofShadowInt(pointR);	    
			        	    	
								Path path = new Path(new Position(posCheck.getLatitude(), posCheck.getLongitude(), posCheck.getElevation()+1),
										new Position(
						             			(SunShading.AppFrame.getGlobe().computePositionFromPoint(intersections.get(0).getIntersectionPoint()).getLatitude()), 
						             			(SunShading.AppFrame.getGlobe().computePositionFromPoint(intersections.get(0).getIntersectionPoint()).getLongitude()),
						             			(SunShading.AppFrame.getGlobe().computePositionFromPoint(intersections.get(0).getIntersectionPoint()).getElevation()-SunShading.AppFrame.getHighResolutionTerrain().getElevation(SunShading.AppFrame.getGlobe().computePositionFromPoint(intersections.get(0).getIntersectionPoint())))
						             			));
				                ShapeAttributes pathAttributes = new BasicShapeAttributes();
				                path.setAltitudeMode(WorldWind.RELATIVE_TO_GROUND);
				                pathAttributes.setOutlineMaterial(Material.BLUE);
				                pathAttributes.setOutlineOpacity(1);
				                pathAttributes.setDrawOutline(true);
				                pathAttributes.setDrawInterior(false);
				                path.setAttributes(pathAttributes); 	    	
				                insertResultRoofShadowPath(path);
	                    	
		                    	PointPlacemark pointE = new PointPlacemark(new Position(posCheck.getLatitude(), posCheck.getLongitude(), posCheck.getElevation()+1));
			         	        PointPlacemarkAttributes pointAttributesE = new PointPlacemarkAttributes();
			        	        pointAttributesE.setUsePointAsDefaultImage(true);
			        	        pointAttributesE.setScale(10.0);
			        	    	pointAttributesE.setLineMaterial(Material.GREEN); 
			        	    	pointE.setAttributes(pointAttributesE);  
			        	    	pointE.setAltitudeMode(WorldWind.RELATIVE_TO_GROUND); 
			        	    	insertResultRoofShadowInt(pointE);	 
			        	    	
			        	    	roofPointObject.setIncidence(SunShading.AppFrame.getGlobe().computePositionFromPoint(intersections.get(0).getIntersectionPoint()).getLatitude().degrees, SunShading.AppFrame.getGlobe().computePositionFromPoint(intersections.get(0).getIntersectionPoint()).getLongitude().degrees, position.getElevation(), 90);	
			        	    	mergePointObject.setIncidence(SunShading.AppFrame.getGlobe().computePositionFromPoint(intersections.get(0).getIntersectionPoint()).getLatitude().degrees, SunShading.AppFrame.getGlobe().computePositionFromPoint(intersections.get(0).getIntersectionPoint()).getLongitude().degrees, position.getElevation(), 90);		        	 
				             }			             
					  }
				}
				catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}			             
				}
	    }

    
	    public void shadowOfElevationOnGround(Position position, PointObject groundPointObject, PointObject mergePointObject)
	    {     
	    	 /**Calculate the shadows of the elevation on the ground*/  
	    	Position ooo = new Position(position.getLatitude(), position.getLongitude(), position.getElevation()+0.50);
	
			Vec4 startPoint = SunShading.AppFrame.getGlobe().computePointFromPosition(ooo);
			
			Line line = new Line(startPoint, SunShading.AppFrame.getSunDirection());			
		
			// Perform the intersection.
			Intersection[] intersections =SunShading.AppFrame.getHighResolutionTerrain().intersect(ooo, SunShading.AppFrame.getGlobe().computePositionFromPoint(line.getPointAt(10000)));			
		
			if (intersections != null) 
			{
		
				Path path= new Path(ooo, SunShading.AppFrame.getGlobe().computePositionFromPoint(line.getPointAt(10e6)));
				   
		        ShapeAttributes pathAttributes = new BasicShapeAttributes();	
	            pathAttributes.setOutlineMaterial(Material.CYAN);  
	            pathAttributes.setInteriorMaterial(Material.CYAN);
	            pathAttributes.setOutlineWidth(2);  
	            path.setAttributes(pathAttributes);
				path.setAltitudeMode(2);
				
				PointPlacemark point = new PointPlacemark(new Position(ooo.getLatitude(), ooo.getLongitude(), ooo.getElevation()+1));  
				point.setAltitudeMode(WorldWind.RELATIVE_TO_GROUND); 	     
				PointPlacemarkAttributes pointAttributes = new PointPlacemarkAttributes();
				pointAttributes.setUsePointAsDefaultImage(true);			
				pointAttributes.setLineMaterial(new Material(new Color(205,133,63))); 
				pointAttributes.setScale(10.0);
				point.setAttributes(pointAttributes);  
				insertResultTerreainInt(point);
				insertResultTerreainPath(path);
				
				groundPointObject.setIncidence(90.0);
				mergePointObject.setIncidence(90.0);
             }           
	    }
	    
	    public void shadowOfElevationOnRoof(Position position, PointObject roofPointObject, PointObject mergePointObject)
	    {     
	    	/**Calculate the elevation's shadows on the roofs*/  
	    	//new iterator to compute intersection of a building with each others
	    	Iterator<?> itr5 = AppFrame.getlistOfBuilding().getBuildingHash().keySet().iterator();
	    	
        	while(itr5.hasNext())
        	{	          		
        			Integer key = (Integer)itr5.next();
	             
        			//filter to compute only the roof's points, not the ground ones
					if (posCheck.getElevation()>position.getElevation()){
  	
					Position ooo = new Position(posCheck.getLatitude(), posCheck.getLongitude(), posCheck.getElevation()+0.50);
					Vec4 startPoint = SunShading.AppFrame.getGlobe().computePointFromPosition(ooo);
								
					Line line = new Line(startPoint, SunShading.AppFrame.getSunDirection());			
					
					Path path= new Path(ooo, SunShading.AppFrame.getGlobe().computePositionFromPoint(line.getPointAt(10e6)));
   
					ShapeAttributes pathAttributes = new BasicShapeAttributes();	
					pathAttributes.setOutlineMaterial(new Material(new Color(210,88,100)));  
					pathAttributes.setInteriorMaterial(new Material(new Color(210,88,100)));
					pathAttributes.setOutlineWidth(2);  
					path.setAttributes(pathAttributes);
					path.setAltitudeMode(2);
					
					// Perform the intersection.
					Intersection[] intersections =SunShading.AppFrame.getHighResolutionTerrain().intersect(ooo, SunShading.AppFrame.getGlobe().computePositionFromPoint(line.getPointAt(10000)));			

						if (intersections != null) 
						{							
							PointPlacemark point = new PointPlacemark(new Position(ooo.getLatitude(), ooo.getLongitude(), ooo.getElevation()+1));  
							point.setAltitudeMode(WorldWind.RELATIVE_TO_GROUND); 	     
							PointPlacemarkAttributes pointAttributes = new PointPlacemarkAttributes();
							pointAttributes.setUsePointAsDefaultImage(true);			
							pointAttributes.setLineMaterial(new Material(new Color(210,88,100))); 
							pointAttributes.setScale(10.0);
							point.setAttributes(pointAttributes);  
							insertResultTerreainInt(point);
							insertResultTerreainPath(path);				
							roofPointObject.setIncidence(90);
							mergePointObject.setIncidence(90);
						}
					}	
			}
	    }

	    public void ghostLayer(double xm, int xgrid, int ygrid,double lat, double lon)
	    {	  	
	    	/** Create the grid and its positions. This one is rectangular; it need not be, but must be four-sided.*/
	    	this.lat=lat;
	    	this.lon=lon;   	
	    	this.xymeter=xm;	    	
	    	NUM_POINTS_WIDE=xgrid;
	    	NUM_POINTS_HIGH=ygrid;
	    	MeterToAngle metA=new MeterToAngle();
	    	
	    	List<Position> ghostcorners = new ArrayList<Position>();
	    	Position base=new Position(Position.fromDegrees(lat, lon), elev);
	    	ghostcorners.add(base);
	    	ghostcorners.add(new Position(base.getLatitude(), base.getLongitude().add(metA.lonMetersAngle(xymeter, lat, lon, globe, dc).multiply(NUM_POINTS_WIDE)), elev));      
	    	ghostcorners.add(new Position(base.getLatitude().add(metA.latMetersAngle(xymeter, lat, lon, globe, dc).multiply(NUM_POINTS_HIGH)), base.getLongitude().add(metA.lonMetersAngle(xymeter, lat, lon, globe, dc).multiply(NUM_POINTS_WIDE)), elev));    
	    	ghostcorners.add(new Position(base.getLatitude().add(metA.latMetersAngle(xymeter, lat, lon, globe, dc).multiply(NUM_POINTS_HIGH)), base.getLongitude(),elev));  
	    	
	        RenderableLayer boundingbox =new RenderableLayer(); 
	    	boundingbox.setPickEnabled(false);
	    	boundingbox.setName("Ghost area");	    	
	    	
	    	ShapeAttributes normalAttributes = new BasicShapeAttributes();
	    	
	    	normalAttributes.setOutlineMaterial(Material.GREEN);
	    	normalAttributes.setInteriorMaterial(Material.GREEN);
	    	normalAttributes.setOutlineWidth(2);           
	    	normalAttributes.setOutlineOpacity(1);
	    	normalAttributes.setInteriorOpacity(0.3);
	    	normalAttributes.setEnableLighting(false);
	    	normalAttributes.setDrawInterior(true);
	    	normalAttributes.setDrawOutline(true);		    		    	   
	    	SurfacePolygon poly= new SurfacePolygon(ghostcorners); 	    		    	
	    	
	    	poly.setAttributes(normalAttributes);
	    	
            ArrayList<Marker> markers = new ArrayList<Marker>();
            PositionIterator iter = new PositionIterator(ghostcorners, NUM_POINTS_WIDE, NUM_POINTS_HIGH);
            MarkerAttributes attrs = new BasicMarkerAttributes();
            attrs.setMaterial(Material.GREEN);
            attrs.setMarkerPixels(0.5);
            attrs.setMaxMarkerSize(0.5);
            attrs.setMinMarkerSize(0.5);
            
            while(iter.hasNext())
            {
            		Position position = iter.next();
                    Marker marker = new BasicMarker(position,  attrs);
                    marker.setPosition(position);
                    marker.setAttributes(attrs);                  
                    markers.add(marker);              
                    
            }

            final MarkerLayer mlayer = new MarkerLayer();
            mlayer.setOverrideMarkerElevation(true);
            mlayer.setElevation(elev);
            mlayer.setKeepSeparated(false);
            mlayer.setEnabled(true);
            mlayer.setMarkers(markers);
            mlayer.setName("Ghost grid");
         
	    	boundingbox.addRenderable(poly);     
	    	
	        SunShading.insertBeforeCompass(this.wwd,boundingbox);
	        SunShading.insertBeforeCompass(this.wwd,mlayer);
	        this.layerPanel.update(this.wwd); 
	    }
	    
	    public void boundingBox(List<Position> boxcorners, double lat, double lon, double xm, int xgrid, int ygrid)
	    {	  	
	    	
	    	ShapeAttributes normalAttributes = new BasicShapeAttributes();
	    	
	    	normalAttributes.setOutlineMaterial(Material.GREEN);
	    	normalAttributes.setInteriorMaterial(Material.GREEN);
	    	normalAttributes.setOutlineWidth(2);           
	    	normalAttributes.setOutlineOpacity(1);
	    	normalAttributes.setInteriorOpacity(0.3);
	    	normalAttributes.setEnableLighting(false);
	    	normalAttributes.setDrawInterior(true);
	    	normalAttributes.setDrawOutline(true);		    		    	
	    	    	
	    	SurfacePolygon poly= new SurfacePolygon(boxcorners); 	    	
    	
	    	poly.setAttributes(normalAttributes);       
        
	    	//analytic surface
	        Sector sector = new Sector (boxcorners.get(0).getLatitude(), boxcorners.get(2).getLatitude(), boxcorners.get(0).getLongitude(), boxcorners.get(2).getLongitude());
	        
	        final AnalyticSurface surface = new AnalyticSurface();
	        AnalyticSurfaceAttributes attr = new AnalyticSurfaceAttributes();
	        attr.setInteriorOpacity(0.6);
	        
	        surface.setSector(sector);
	        surface.setDimensions(NUM_POINTS_WIDE,NUM_POINTS_HIGH);
	        surface.setAltitudeMode(WorldWind.CLAMP_TO_GROUND);	        
	        surface.setPickObject( surface.getClientLayer());
	        surface.setSurfaceAttributes(attr);	   

	        ArrayList<AnalyticSurface.GridPointAttributes> attributesList = new ArrayList<AnalyticSurface.GridPointAttributes>(NUM_POINTS_WIDE*NUM_POINTS_HIGH);

	        for(int c= 0; c< NUM_POINTS_WIDE*NUM_POINTS_HIGH; c++)
	        {attributesList.add(c, AnalyticSurface.createGridPointAttributes(c, new Color(255,0,0)));}; 
	        
	        int il=0;	     
		    for(int c= 0; c< NUM_POINTS_WIDE; c++)
		      {			    		    	 
		          for(int r= 0; r< NUM_POINTS_HIGH ; r++)
		          {    
			        	if ( ( (c^r) & 1) == 1)
			          	{
			          		attributesList.set(il, AnalyticSurface.createGridPointAttributes(il, new Color(255,0,0))); 		          		  
			          	 }
		          		
		          	if ( ( (c) & 1) == 0)
		          	{
		          		attributesList.set(il, AnalyticSurface.createGridPointAttributes(il, new Color(255,255,255))); 		          		  
		          	 }
		          	
		          	if ( ( (r) & 1) == 1)
		          	{
		          		attributesList.set(il, AnalyticSurface.createGridPointAttributes(il, new Color(0,0,0))); 		          		  
		          	 }
		          	il++;
		          }		       
		      }  
	    surface.setValues(attributesList);	    	
	    };
	    
	
	protected static class PointObject
	{	/**create a point object*/
		double lat;
		double lon;
		double elev;		
		double slope;
		double aspect;
		double incidence;
		
	    public PointPlacemark createPointObject(Position position, Angle slope, Angle aspect, double value)
	    {   /**create a point placemark*/    
	    	this.lat=position.getLatitude().degrees;
	    	this.lon=position.getLongitude().degrees;     	
	        PointPlacemark point = new PointPlacemark(new Position(position, 0));          
	        point.setAltitudeMode(WorldWind.RELATIVE_TO_GROUND); 	     
	        PointPlacemarkAttributes pointAttributes = new PointPlacemarkAttributes();
	        pointAttributes.setUsePointAsDefaultImage(true);
	        pointAttributes.setScale(2.0);	        
	        point.setLabelText(" i "+Math.round(value));	       
	    	point.setAttributes(pointAttributes);               
	    	pointAttributes.setLineMaterial(Material.CYAN); 	    	
	    	return point;
	    }
	    
	    public PointPlacemark createPointObject(Position position, double value)
	    {   /**create a point placemark*/        	
	        PointPlacemark point = new PointPlacemark(new Position(position, 0));          
	        point.setAltitudeMode(WorldWind.RELATIVE_TO_GROUND); 	     
	        PointPlacemarkAttributes pointAttributes = new PointPlacemarkAttributes();
	        pointAttributes.setUsePointAsDefaultImage(true);
	        pointAttributes.setScale(2.0);	        
	        point.setLabelText(" i "+Math.round(value));	        
	    	point.setAttributes(pointAttributes);               
	    	pointAttributes.setLineMaterial(Material.CYAN); 	    	
	    	return point;
	    }
	    
	    public void setPointValues(double lat, double lon, double elevation, double slope, double aspect, double incidence)
	    {  	/**set values*/
	    	this.lat=lat;
	    	this.lon=lon;
	    	this.elev=elevation;
	    	this.slope=slope;
	    	this.aspect=aspect;
	    	this.incidence=incidence;
	    }
	    
	    public void setIncidence(double lat, double lon, double elevation, double incidence)
	    { 	/**set incidence angle*/
	    	this.lat=lat;
	    	this.lon=lon;
	    	this.elev=elevation;
	    	this.incidence=incidence;
	    }
	    
	    public void setIncidence(double incidence)
	    { 	/**set incidence angle*/
	    	this.incidence=incidence;
	    }
	    
	    public void setLat(double lat)
	    {	/**set latitude*/
	    	this.lat=lat;
	    }
	    
	    public void setLon(double lon)
	    {	/**set longitude*/
	    	this.lon=lon;
	    }
	    
	    public void setElevation(double elevation)
	    {
	    	/**set elevation*/
	    	this.elev=elevation;
	    }
	    
	    public void setAspect(double aspect)
	    {	/**set aspect*/
	    	this.aspect=aspect;
	    }
	    
	    public void setSlope(double slope)
	    {	/**set slope*/
	    	this.slope=slope;
	    }	    
	    
	    public double getPointLat()
	    {	/**get latitude*/
	    	return this.lat;
	    }
	    
	    public double getPointLon()
	    {	/**get longitude*/
	    	return this.lon;
	    }
	    
	    public double getPointElevation()
	    {	/**get elevation*/
	    	return this.elev;
	    }
	    
	    public double getPointAspect()
	    {	/**get aspect*/
	    	return this.aspect;
	    }
	    
	    public double getSlope()
	    {	/**get slope*/
	    	return this.slope;
	    }
	    
	    public double getIndicence()
	    {	/**get incidence*/
	    	return this.incidence;
	    }
	}
	


		        
	
	private static class PositionIterator implements Iterator<Position>
	{ 	/** Generates positions forming a lat/lon grid. */
	    private int numWide = NUM_POINTS_WIDE;
	    private int numHigh = NUM_POINTS_HIGH;
	    private int w;
	    private int h;
	
	    private List<Position> corners;
	    private Position sw;
	    private Position se;
	    private Position ne;
	    private Position nw;
	
	    public PositionIterator(List<Position> corners, int numPointsWide, int numPointsHigh)
	    {
	        this.corners = corners;
	        this.sw = corners.get(0);
	        this.se = corners.get(1);
	        this.ne = corners.get(2);
	        this.nw = corners.get(3);
	
	        this.numWide = numPointsWide;
	        this.numHigh = numPointsHigh;
	    }
	
	    public boolean hasNext()
	    {
	        return this.h < this.numHigh;
	    }
	
	    public Position next()
	    {
	        if (this.h >= this.numHigh)
	            throw new NoSuchElementException("PointGridIterator");
	
	        return this.computeNextPosition();
	    }
	
	    public void remove()
	    {
	        throw new UnsupportedOperationException("PointGridIterator");
	    }
	
	    private Position computeNextPosition()
	    {
	        Position left, right;
	
	        if (h == 0)
	        {
	            left = sw;
	            right = se;
	        }
	        else if (h == numHigh - 1)
	        {
	            left = nw;
	            right = ne;
	        }
	        else
	        {
	            double t = h / (double) (numHigh - 1);
	
	            left = Position.interpolate(t, sw, nw);
	            right = Position.interpolate(t, se, ne);
	        }
	
	        Position pos;
	
	        if (w == 0)
	        {
	            pos = left;
	            ++w;
	        }
	        else if (w == numWide - 1)
	        {
	            pos = right;
	
	            w = ++h < numHigh ? 0 : w + 1;
	        }
	        else
	        {
	            double s = w / (double) (numWide - 1);
	            pos = Position.interpolate(s, left, right);
	            ++w;
	        }
	
	        return pos;
	    }
	} 
	
		
    
    private static BufferWrapper myPutGridValues(double[] dIncidence, double smoothness, BufferFactory factory)
    {	/** Function to create the buffer for the analytic surface*/
        int numValues = dIncidence.length;

        BufferWrapper buffer = factory.newBuffer(numValues);
        buffer.putDouble(0, dIncidence, 0, numValues);

        return buffer;
    }
	
    
   
    public void createIncidenceSurface(double minHue, double maxHue,  List<Double> valueAnalitic, List<Position> gridcorners, final RenderableLayer outLayer, int altitude)
    { 	/** Function to create the analytic surface*/
        double min = valueAnalitic.get(0), max = valueAnalitic.get(0);            
       
        final AnalyticSurface surface = new AnalyticSurface();
        Sector sector = new Sector (gridcorners.get(2).getLatitude(), gridcorners.get(0).getLatitude(), gridcorners.get(0).getLongitude(), gridcorners.get(2).getLongitude());        
    		 
        for (int i=0;i<(NUM_POINTS_WIDE * NUM_POINTS_HIGH);i++)
        {
        	if (valueAnalitic.get(i)<min)
        		min = valueAnalitic.get(i);
        	if (valueAnalitic.get(i)>max)
        		max = valueAnalitic.get(i);         	
        }     

        surface.setSector(sector);
        surface.setAltitudeMode(WorldWind.RELATIVE_TO_GROUND);
        surface.setAltitude(altitude);
        surface.setVerticalScale(0);
        surface.setDimensions(NUM_POINTS_WIDE, NUM_POINTS_HIGH);

        double[] dIrrG = new double [NUM_POINTS_WIDE * NUM_POINTS_HIGH];
        
        for (int i=0; i<NUM_POINTS_WIDE * NUM_POINTS_HIGH; i++)
        {
        	dIrrG[i] = valueAnalitic.get(i);
        }

        BufferWrapper firstBuffer = myPutGridValues(dIrrG, 0.5d, new BufferFactory.DoubleBufferFactory());
       
        surface.setValues( AnalyticSurface.createColorGradientValues(
        		firstBuffer, MISSING_DATA_SIGNAL , min, max, minHue, maxHue)  );

        AnalyticSurfaceAttributes attr = new AnalyticSurfaceAttributes();
        attr.setDrawOutline(false);
        attr.setDrawShadow(false);
        attr.setInteriorOpacity(1);
        surface.setSurfaceAttributes(attr);
       
        Format legendLabelFormat = new DecimalFormat("# ") //# �
        {
            public StringBuffer format(double number, StringBuffer result, FieldPosition fieldPosition)
            {
                return super.format(number, result, fieldPosition);
            }
        };
        
        final AnalyticSurfaceLegend legend = AnalyticSurfaceLegend.fromColorGradient(min, max,
                minHue, maxHue,
                AnalyticSurfaceLegend.createDefaultColorGradientLabels(min, max, legendLabelFormat),
                AnalyticSurfaceLegend.createDefaultTitle("Irradiance W/mq"));
        legend.setOpacity(0.8);
        legend.setScreenLocation(new Point(100, 300));

        SwingUtilities.invokeLater(new Runnable()
        {
            public void run()
            {
                surface.setClientLayer(outLayer);
                outLayer.addRenderable(surface);
                outLayer.addRenderable(createLegendRenderable(surface, 300, legend));
                SunShading.insertBeforeCompass(wwd, outLayer);
            }
        });
    }

    protected static Renderable createLegendRenderable(final AnalyticSurface surface, final double surfaceMinScreenSize,
            final AnalyticSurfaceLegend legend)
        {
            return new Renderable()
            {
                public void render(DrawContext dc)
                {
                    Extent extent = surface.getExtent(dc);
                    if (!extent.intersects(dc.getView().getFrustumInModelCoordinates()))
                        return;

                    if (WWMath.computeSizeInWindowCoordinates(dc, extent) < surfaceMinScreenSize)
                        return;

                    legend.render(dc);
                }
            };
        }
    
    
    
    protected void initAnalyticSurfaceLayer()
    {
    	//create three analytic surfaces
    	analyticSurfaceLayer.setPickEnabled(false);
    	analyticSurfaceLayer.setName("Analytic Surfaces Ground"); 
    	
    	analyticSurfaceLayerRoof.setPickEnabled(false);
    	analyticSurfaceLayerRoof.setName("Analytic Surfces Roof");    	
    	
    	analyticSurfaceLayerMerge.setPickEnabled(false);
    	analyticSurfaceLayerMerge.setName("Analytic Surfaces Merge");    	
    	
        SunShading.insertBeforeCompass(this.wwd, analyticSurfaceLayer);
        SunShading.insertBeforeCompass(this.wwd, analyticSurfaceLayerRoof);
        SunShading.insertBeforeCompass(this.wwd, analyticSurfaceLayerMerge);
        
        this.layerPanel.update(this.wwd);

        Thread t = new Thread(new Runnable()
        {
            public void run()
            {           	
            	createIncidenceSurface(HUE_BLUE, HUE_RED, groundAnalytic, gridcorners, analyticSurfaceLayer,1);
            	createIncidenceSurface(HUE_BLUE, HUE_RED, roofAnalytic, gridcorners, analyticSurfaceLayerRoof, 40);
            	createIncidenceSurface(HUE_BLUE, HUE_RED, mergeAnalytic, gridcorners, analyticSurfaceLayerMerge, 60);
            }
        });
        t.start();
    }
}
