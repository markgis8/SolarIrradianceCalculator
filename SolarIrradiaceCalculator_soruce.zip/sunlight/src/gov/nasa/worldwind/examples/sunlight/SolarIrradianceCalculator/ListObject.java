package gov.nasa.worldwind.examples.sunlight.SolarIrradianceCalculator;

import java.util.HashMap;

/**
 * Copyright (C) 2001 United States Government
 * as represented by the Administrator of the
 * National Aeronautics and Space Administration.
 * All Rights Reserved.
 * @author  Marco Piragnolo
 * Cirgeo, University of Padua, francesco.pirotti@unipd.it, marco.piragnolo@unipd.it
 * @version 0.1  2014-29-05 11:46
 */

public class ListObject {
	/** this is a hashmap of buildings */
	private HashMap<Integer, Object> hashBuilding;
		
		public ListObject()
		{	/** create hashmap of buildings */		
			HashMap<Integer,  Object> hashBuilding= new HashMap<Integer,  Object>();
			this.hashBuilding=hashBuilding;			
		}	
		
		public void clearListObject()
		{			
			hashBuilding.clear();			
		}	
		
        public void insertBuildingHash(int index, Object obj)
        {   /** insert object in the hashmap */     	
        	hashBuilding.put(index, obj);
        }
        
        public HashMap<Integer,  Object> getBuildingHash()
        {	/** get hashmap of buildings */
        	return hashBuilding;      	
        }   
}

