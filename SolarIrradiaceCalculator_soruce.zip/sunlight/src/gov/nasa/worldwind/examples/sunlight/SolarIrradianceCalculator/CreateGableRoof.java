package gov.nasa.worldwind.examples.sunlight.SolarIrradianceCalculator;

import java.awt.Color;

import gov.nasa.worldwind.WorldWindow;
import gov.nasa.worldwind.globes.Globe;
import gov.nasa.worldwind.render.BasicShapeAttributes;
import gov.nasa.worldwind.render.DrawContext;
import gov.nasa.worldwind.render.ExtrudedPolygon;
import gov.nasa.worldwind.render.Material;
import gov.nasa.worldwind.render.ShapeAttributes;
import gov.nasa.worldwindx.examples.LayerPanel;
/**
 * Copyright (C) 2001 United States Government
 * as represented by the Administrator of the
 * National Aeronautics and Space Administration.
 * All Rights Reserved.
 * @author  Marco Piragnolo
 * Cirgeo, University of Padua, francesco.pirotti@unipd.it, marco.piragnolo@unipd.it
 * @version 0.1  2014-29-05 11:46
 */
// 2 sheets roof

class CreateGableNorth extends Building{
	/** Create a building with a gable roof to north*/
	public CreateGableNorth (double lat, double lon,
			double lenght, double width, double height,
			double slope, int aspect, int aspectSide, Globe globe,
			WorldWindow wwd, LayerPanel layerPanel, DrawContext dc) 
	{
		super(lat, lon, lenght, width, height, slope, aspect, aspectSide, globe, wwd, layerPanel, dc);
		calculateGable();			
		
		 ShapeAttributes sideAttributes = new BasicShapeAttributes();
		 	
            sideAttributes.setInteriorMaterial(new Material(new Color(182, 246, 255)));                
            sideAttributes.setOutlineOpacity(1);
            sideAttributes.setInteriorOpacity(1);
            sideAttributes.setOutlineMaterial(Material.BLACK);
            sideAttributes.setOutlineWidth(2);
            sideAttributes.setDrawOutline(true);
            sideAttributes.setDrawInterior(true);
            sideAttributes.setEnableLighting(true);

            final ShapeAttributes capAttributes = new BasicShapeAttributes(sideAttributes);
            capAttributes.setInteriorMaterial(Material.ORANGE);           
            capAttributes.setInteriorOpacity(1);
            
            ExtrudedPolygon  poly2n = new ExtrudedPolygon (positions2n);           
              float[] texCoords = new float[] {1,1, 1, 0, 0, 0, 0, 1};       
            poly2n.setCapImageSource("images/roof36.jpg", texCoords, 4);
            poly2n.setSideAttributes(sideAttributes);         
            poly2n.setCapAttributes(capAttributes);
            poly2n.setAltitudeMode(2);
            setPolygon(poly2n);      	  
	    
            //calculate the normal to the roof
	        computeNormalBuilding(positions2n.get(3), positions2n.get(0), positions2n.get(1), getBaricenter(positions2n));
	}	
}	


class CreateGableSouth extends Building{
	/** Create a building with a gable roof to south*/
	public CreateGableSouth (double lat, double lon,
			double lenght, double width, double height,
			double slope, int aspect, int aspectSide, Globe globe,
			WorldWindow wwd, LayerPanel layerPanel, DrawContext dc) 
	{
		super(lat, lon, lenght, width, height, slope, aspect, aspectSide, globe, wwd, layerPanel, dc);
		calculateGable();			
		
		 ShapeAttributes sideAttributes = new BasicShapeAttributes();
            sideAttributes.setInteriorMaterial(new Material(new Color(182, 246, 255)));            
            sideAttributes.setOutlineOpacity(1);
            sideAttributes.setInteriorOpacity(1);
            sideAttributes.setOutlineMaterial(Material.BLACK);
            sideAttributes.setOutlineWidth(2);
            sideAttributes.setDrawOutline(true);
            sideAttributes.setDrawInterior(true);
            sideAttributes.setEnableLighting(true);

            final ShapeAttributes capAttributes = new BasicShapeAttributes(sideAttributes);
            capAttributes.setInteriorMaterial(Material.ORANGE);           
            capAttributes.setInteriorOpacity(1);
            ExtrudedPolygon  poly2s = new ExtrudedPolygon (positions2s);
            float[] texCoords = new float[] {0, 0, 1, 0, 1, 1, 0, 1};
            poly2s.setCapImageSource("images/roof37.jpg", texCoords, 4);
            poly2s.setSideAttributes(sideAttributes);         
            poly2s.setCapAttributes(capAttributes);
            poly2s.setAltitudeMode(2);
            setPolygon(poly2s);
            
	        computeNormalBuilding(positions2s.get(3), positions2s.get(0), positions2s.get(1), getBaricenter(positions2s));
	}
}	


class CreateGableEast extends Building{
	/** Create a building with a gable roof to south*/
	public CreateGableEast (double lat, double lon,
			double lenght, double width, double height,
			double slope, int aspect, int aspectSide, Globe globe,
			WorldWindow wwd, LayerPanel layerPanel, DrawContext dc) 
	{
		super(lat, lon, lenght, width, height, slope, aspect, aspectSide, globe, wwd, layerPanel, dc);
		calculateGable();			
		
		 ShapeAttributes sideAttributes = new BasicShapeAttributes();
            sideAttributes.setInteriorMaterial(new Material(new Color(182, 246, 255)));            
            sideAttributes.setOutlineOpacity(1);
            sideAttributes.setInteriorOpacity(1);
            sideAttributes.setOutlineMaterial(Material.BLACK);
            sideAttributes.setOutlineWidth(2);
            sideAttributes.setDrawOutline(true);
            sideAttributes.setDrawInterior(true);
            sideAttributes.setEnableLighting(true);

            final ShapeAttributes capAttributes = new BasicShapeAttributes(sideAttributes);
            capAttributes.setInteriorMaterial(Material.ORANGE);           
           
            ExtrudedPolygon  poly2e = new ExtrudedPolygon (positions2e);
            poly2e.setSideAttributes(sideAttributes);         
            poly2e.setCapAttributes(capAttributes);
            poly2e.setAltitudeMode(2);
            float[] texCoords = new float[] {0, 0, 0, 1, 1, 1, 1, 0};
            poly2e.setCapImageSource("images/roof37.jpg", texCoords, 4);
            setPolygon(poly2e);
	        computeNormalBuilding(positions2e.get(3), positions2e.get(0), positions2e.get(1), getBaricenter(positions2e));
	}
}

class CreateGableWest extends Building{
	/** Create a building with a gable roof to west*/
	public CreateGableWest (double lat, double lon,
			double lenght, double width, double height,
			double slope, int aspect, int aspectSide, Globe globe,
			WorldWindow wwd, LayerPanel layerPanel, DrawContext dc) 
	{
		super(lat, lon, lenght, width, height, slope, aspect, aspectSide, globe, wwd, layerPanel, dc);
		calculateGable();			
		
		 ShapeAttributes sideAttributes = new BasicShapeAttributes();
            sideAttributes.setInteriorMaterial(new Material(new Color(182, 246, 255)));            
            sideAttributes.setOutlineOpacity(1);
            sideAttributes.setInteriorOpacity(1);
            sideAttributes.setOutlineMaterial(Material.BLACK);
            sideAttributes.setOutlineWidth(2);
            sideAttributes.setDrawOutline(true);
            sideAttributes.setDrawInterior(true);
            sideAttributes.setEnableLighting(true);

            ShapeAttributes capAttributes = new BasicShapeAttributes(sideAttributes);
            capAttributes.setInteriorMaterial(Material.ORANGE);
          
            ExtrudedPolygon  poly2w = new ExtrudedPolygon (positions2w);
            poly2w.setSideAttributes(sideAttributes);         
            poly2w.setCapAttributes(capAttributes);
            poly2w.setAltitudeMode(2);
            float[] texCoords = new float[] {0, 0, 1, 0, 1, 1, 0, 1};
            poly2w.setCapImageSource("images/roof37.jpg", texCoords, 4);
            setPolygon(poly2w);
	        computeNormalBuilding(positions2w.get(3), positions2w.get(0), positions2w.get(1), getBaricenter(positions2w));
	}
}
