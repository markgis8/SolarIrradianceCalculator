package gov.nasa.worldwind.examples.sunlight.SolarIrradianceCalculator;

import gov.nasa.worldwind.WorldWind;
import gov.nasa.worldwind.WorldWindow;
import gov.nasa.worldwind.avlist.AVKey;
import gov.nasa.worldwind.geom.Position;
import gov.nasa.worldwind.globes.Globe;
import gov.nasa.worldwind.layers.RenderableLayer;
import gov.nasa.worldwind.render.BasicShapeAttributes;
import gov.nasa.worldwind.render.Material;
import gov.nasa.worldwind.render.Path;
import gov.nasa.worldwind.render.ShapeAttributes;
import gov.nasa.worldwindx.examples.LayerPanel;
/*
public class RayLight {
	
	private WorldWindow wwd;
	private LayerPanel layerPanel;
	private Globe globe;
	
	public Path rayLight(WorldWindow wwd, Globe globe, LayerPanel layerPanel, Position centerPosition, String value)
    {     	
        this.wwd=wwd;
		this.globe= globe;
        this.layerPanel=layerPanel;
        RenderableLayer line = new RenderableLayer(); 
        line.setName("Raylight");
        Path path = null;          
        //calculate sun position
		Position pos = globe.computePositionFromPoint(SunShading.AppFrame.getSunPosition()); 		
		//start point
		Position pA= new Position(pos.getLatitude(), pos.getLongitude(), pos.getElevation());
		//end point
        Position pB=new Position(centerPosition.getLatitude(), centerPosition.getLongitude(), centerPosition.getElevation());
        //draw path
        path = new Path(pB, pA );
        ShapeAttributes pathAttributes = new BasicShapeAttributes();
        path.setAltitudeMode(WorldWind.RELATIVE_TO_GROUND);
        pathAttributes.setOutlineMaterial(Material.YELLOW);   
        pathAttributes.setInteriorMaterial(Material.YELLOW);
        pathAttributes.setOutlineWidth(1);     
        path.setAttributes(pathAttributes);
        path.setValue(AVKey.DISPLAY_NAME, value);
		line.addRenderable(path);

        // Add the layer to the model.
        SunShading.insertBeforeCompass(wwd, line);

        // Update layer panel
        this.layerPanel.update(this.wwd);
        
		return path;        
    }	
}
*/